﻿
namespace _3450_final_design_project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblusername = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.btnnormaluser = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnlogin = new System.Windows.Forms.Button();
            this.lbltitle = new System.Windows.Forms.Label();
            this.tabswitch = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblplayermode = new System.Windows.Forms.Label();
            this.btnadminplayerdelete = new System.Windows.Forms.Button();
            this.btnadminplayerupdate = new System.Windows.Forms.Button();
            this.btnadminplayeradd = new System.Windows.Forms.Button();
            this.gridadminplayer = new System.Windows.Forms.DataGridView();
            this.playerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerJerseyNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerLnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerFnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerNatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerDOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerHeightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerWeightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerGoalsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerAssistsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerPosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerValUSDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.natTeamCountryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubClubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pldataDataSet = new _3450_final_design_project.pldataDataSet();
            this.lbladmintext = new System.Windows.Forms.Label();
            this.lbladminvaluefilter = new System.Windows.Forms.Label();
            this.cbadminvaluefilter = new System.Windows.Forms.ComboBox();
            this.lbladminnamefilter = new System.Windows.Forms.Label();
            this.lbladmingoalfilter = new System.Windows.Forms.Label();
            this.cbadminnamefilter = new System.Windows.Forms.ComboBox();
            this.cbadmingoalfilter = new System.Windows.Forms.ComboBox();
            this.btnadminnational = new System.Windows.Forms.Button();
            this.btnadmincomp = new System.Windows.Forms.Button();
            this.btnadminrecord = new System.Windows.Forms.Button();
            this.btnadminmanager = new System.Windows.Forms.Button();
            this.btnadminclub = new System.Windows.Forms.Button();
            this.btnadminplayer = new System.Windows.Forms.Button();
            this.txtadminplayer = new System.Windows.Forms.TextBox();
            this.btnadminfilter = new System.Windows.Forms.Button();
            this.lbladminpageswitch = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label38 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.btnaddplayer = new System.Windows.Forms.Button();
            this.lblplayeradd = new System.Windows.Forms.Label();
            this.lbltitleadd = new System.Windows.Forms.Label();
            this.lblat14 = new System.Windows.Forms.Label();
            this.lblat13 = new System.Windows.Forms.Label();
            this.lblat12 = new System.Windows.Forms.Label();
            this.lblat11 = new System.Windows.Forms.Label();
            this.lblat10 = new System.Windows.Forms.Label();
            this.lblat9 = new System.Windows.Forms.Label();
            this.lblat8 = new System.Windows.Forms.Label();
            this.lblat7 = new System.Windows.Forms.Label();
            this.lblat6 = new System.Windows.Forms.Label();
            this.lblat5 = new System.Windows.Forms.Label();
            this.lblat4 = new System.Windows.Forms.Label();
            this.lblat3 = new System.Windows.Forms.Label();
            this.lblat2 = new System.Windows.Forms.Label();
            this.lblat1 = new System.Windows.Forms.Label();
            this.txtat14 = new System.Windows.Forms.TextBox();
            this.txtat13 = new System.Windows.Forms.TextBox();
            this.txtat12 = new System.Windows.Forms.TextBox();
            this.txtat11 = new System.Windows.Forms.TextBox();
            this.txtat10 = new System.Windows.Forms.TextBox();
            this.txtat9 = new System.Windows.Forms.TextBox();
            this.txtat8 = new System.Windows.Forms.TextBox();
            this.txtat7 = new System.Windows.Forms.TextBox();
            this.txtat6 = new System.Windows.Forms.TextBox();
            this.txtat5 = new System.Windows.Forms.TextBox();
            this.txtat4 = new System.Windows.Forms.TextBox();
            this.txtat3 = new System.Windows.Forms.TextBox();
            this.txtat2 = new System.Windows.Forms.TextBox();
            this.txtat1 = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label39 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.txtdelete1 = new System.Windows.Forms.TextBox();
            this.lbldelete1 = new System.Windows.Forms.Label();
            this.btndeleteplayer = new System.Windows.Forms.Button();
            this.txtdelete = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbldelete = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label40 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.txtupdatestart = new System.Windows.Forms.TextBox();
            this.lblupdatestart = new System.Windows.Forms.Label();
            this.txtvalupdate = new System.Windows.Forms.TextBox();
            this.lblvalnew = new System.Windows.Forms.Label();
            this.txtupdateID = new System.Windows.Forms.TextBox();
            this.lblupdateID = new System.Windows.Forms.Label();
            this.btnupdate = new System.Windows.Forms.Button();
            this.txtupdateatt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblupdateatt = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.lblclubmode = new System.Windows.Forms.Label();
            this.btnclub2player = new System.Windows.Forms.Button();
            this.gridclub = new System.Windows.Forms.DataGridView();
            this.clubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubStadiumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubCapacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.managerManIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pldataDataSet1 = new _3450_final_design_project.pldataDataSet();
            this.label10 = new System.Windows.Forms.Label();
            this.btnclubdelete = new System.Windows.Forms.Button();
            this.btnclubupdate = new System.Windows.Forms.Button();
            this.btnclubadd = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.clubfiltercap = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.clubfiltername = new System.Windows.Forms.ComboBox();
            this.clubfiltercity = new System.Windows.Forms.ComboBox();
            this.btnclub2nat = new System.Windows.Forms.Button();
            this.btnclub2comp = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btnclub2man = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.txtsearchclub = new System.Windows.Forms.TextBox();
            this.btnfilterclub = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.lblmanmode = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btnman2player = new System.Windows.Forms.Button();
            this.gridman = new System.Windows.Forms.DataGridView();
            this.manIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manLnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manFnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manNatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manDOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.managerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label11 = new System.Windows.Forms.Label();
            this.btnmandelete = new System.Windows.Forms.Button();
            this.btnmanupdate = new System.Windows.Forms.Button();
            this.btnmanadd = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.ma = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.btnman2nat = new System.Windows.Forms.Button();
            this.btnman2comp = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.btnman2club = new System.Windows.Forms.Button();
            this.txtsearchman = new System.Windows.Forms.TextBox();
            this.btnmanfilter = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.lblnatmode = new System.Windows.Forms.Label();
            this.btnnat2player = new System.Windows.Forms.Button();
            this.gridnat = new System.Windows.Forms.DataGridView();
            this.natTeamCountryDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.natTeamStadiumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.natTeamCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.natTeamCapacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nationalteamBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label20 = new System.Windows.Forms.Label();
            this.btnnatdelete = new System.Windows.Forms.Button();
            this.btnnatupdate = new System.Windows.Forms.Button();
            this.btnnatadd = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.natteamcap = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.natfiltername = new System.Windows.Forms.ComboBox();
            this.natteamcity = new System.Windows.Forms.ComboBox();
            this.button9 = new System.Windows.Forms.Button();
            this.btnnat2comp = new System.Windows.Forms.Button();
            this.btnnat2hist = new System.Windows.Forms.Button();
            this.btnnat2man = new System.Windows.Forms.Button();
            this.btnnat2club = new System.Windows.Forms.Button();
            this.txtsearchnat = new System.Windows.Forms.TextBox();
            this.btnnatfilter = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.lblhismode = new System.Windows.Forms.Label();
            this.btnhis2player = new System.Windows.Forms.Button();
            this.gridhis = new System.Windows.Forms.DataGridView();
            this.pLAYERLNAMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pLAYERFNAMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cLUBNAMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tEAMSTARTDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerrecordview1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pldataDataSet21 = new _3450_final_design_project.pldataDataSet2();
            this.label26 = new System.Windows.Forms.Label();
            this.btnhisdelete = new System.Windows.Forms.Button();
            this.btnhisupdate = new System.Windows.Forms.Button();
            this.btnhisadd = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.hisfilterdate = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.hisfiltername = new System.Windows.Forms.ComboBox();
            this.hisfilterclub = new System.Windows.Forms.ComboBox();
            this.btnhisttonat = new System.Windows.Forms.Button();
            this.btnhist2comp = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.btnhis2man = new System.Windows.Forms.Button();
            this.btnhis2club = new System.Windows.Forms.Button();
            this.txtsearchhis = new System.Windows.Forms.TextBox();
            this.btnhisfilter = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.lblcompmode = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.btncomp2play = new System.Windows.Forms.Button();
            this.gridcomp = new System.Windows.Forms.DataGridView();
            this.cLUBIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cLUBNAMEDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMPNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTATUSNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.compviewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pldataDataSet3 = new _3450_final_design_project.pldataDataSet3();
            this.label32 = new System.Windows.Forms.Label();
            this.btncompdelete = new System.Windows.Forms.Button();
            this.btncompupdate = new System.Windows.Forms.Button();
            this.btncompadd = new System.Windows.Forms.Button();
            this.compfiltstat = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.compfiltcomp = new System.Windows.Forms.ComboBox();
            this.compfilterclub = new System.Windows.Forms.ComboBox();
            this.btncomp2nat = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.btncomp2his = new System.Windows.Forms.Button();
            this.btncomp2man = new System.Windows.Forms.Button();
            this.btncomp2club = new System.Windows.Forms.Button();
            this.txtsearchcomp = new System.Windows.Forms.TextBox();
            this.btncompfilter = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label36 = new System.Windows.Forms.Label();
            this.playerrecordBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pldataDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.playerrecordibfk1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.competitionstatushasclubibfk2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.playerrecordibfk1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.playerrecordBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.playerrecordBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.playerTableAdapter = new _3450_final_design_project.pldataDataSetTableAdapters.playerTableAdapter();
            this.clubTableAdapter = new _3450_final_design_project.pldataDataSetTableAdapters.clubTableAdapter();
            this.managerTableAdapter = new _3450_final_design_project.pldataDataSetTableAdapters.managerTableAdapter();
            this.national_teamTableAdapter = new _3450_final_design_project.pldataDataSetTableAdapters.national_teamTableAdapter();
            this.player_recordTableAdapter = new _3450_final_design_project.pldataDataSetTableAdapters.player_recordTableAdapter();
            this.competition_status_has_clubTableAdapter = new _3450_final_design_project.pldataDataSetTableAdapters.competition_status_has_clubTableAdapter();
            this.pldataDataSet2 = new _3450_final_design_project.pldataDataSet();
            this.playerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.player_record_view1TableAdapter = new _3450_final_design_project.pldataDataSet2TableAdapters.player_record_view1TableAdapter();
            this.comp_viewTableAdapter = new _3450_final_design_project.pldataDataSet3TableAdapters.comp_viewTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabswitch.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridadminplayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridclub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clubBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.managerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridnat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nationalteamBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridhis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordview1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridcomp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.compviewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordibfk1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.competitionstatushasclubibfk2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordibfk1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(310, 312);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(63, 16);
            this.lblusername.TabIndex = 0;
            this.lblusername.Text = "Username:";
            this.lblusername.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.Location = new System.Drawing.Point(310, 350);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(59, 16);
            this.lblpassword.TabIndex = 1;
            this.lblpassword.Text = "Password:";
            // 
            // txtusername
            // 
            this.txtusername.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.Location = new System.Drawing.Point(394, 309);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(100, 23);
            this.txtusername.TabIndex = 2;
            // 
            // txtpassword
            // 
            this.txtpassword.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(394, 347);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(100, 23);
            this.txtpassword.TabIndex = 3;
            this.txtpassword.TextChanged += new System.EventHandler(this.txtpassword_TextChanged);
            // 
            // btnnormaluser
            // 
            this.btnnormaluser.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnormaluser.Location = new System.Drawing.Point(505, 376);
            this.btnnormaluser.Name = "btnnormaluser";
            this.btnnormaluser.Size = new System.Drawing.Size(146, 54);
            this.btnnormaluser.TabIndex = 4;
            this.btnnormaluser.Text = "Continue as Normal User";
            this.btnnormaluser.UseVisualStyleBackColor = true;
            this.btnnormaluser.Click += new System.EventHandler(this.btnnormaluser_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(250, 65);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 225);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnlogin
            // 
            this.btnlogin.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogin.Location = new System.Drawing.Point(222, 376);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.Size = new System.Drawing.Size(146, 54);
            this.btnlogin.TabIndex = 6;
            this.btnlogin.Text = "Login as Admin";
            this.btnlogin.UseVisualStyleBackColor = true;
            this.btnlogin.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Goudy Old Style", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.Location = new System.Drawing.Point(260, 18);
            this.lbltitle.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(400, 32);
            this.lbltitle.TabIndex = 7;
            this.lbltitle.Text = "PREMIER LEAGUE DATABASE";
            // 
            // tabswitch
            // 
            this.tabswitch.Controls.Add(this.tabPage1);
            this.tabswitch.Controls.Add(this.tabPage2);
            this.tabswitch.Controls.Add(this.tabPage3);
            this.tabswitch.Controls.Add(this.tabPage4);
            this.tabswitch.Controls.Add(this.tabPage5);
            this.tabswitch.Controls.Add(this.tabPage6);
            this.tabswitch.Controls.Add(this.tabPage7);
            this.tabswitch.Controls.Add(this.tabPage8);
            this.tabswitch.Controls.Add(this.tabPage9);
            this.tabswitch.Controls.Add(this.tabPage10);
            this.tabswitch.Location = new System.Drawing.Point(-7, -31);
            this.tabswitch.Name = "tabswitch";
            this.tabswitch.SelectedIndex = 0;
            this.tabswitch.Size = new System.Drawing.Size(1315, 587);
            this.tabswitch.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPage1.Controls.Add(this.txtusername);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.lblusername);
            this.tabPage1.Controls.Add(this.lbltitle);
            this.tabPage1.Controls.Add(this.btnlogin);
            this.tabPage1.Controls.Add(this.btnnormaluser);
            this.tabPage1.Controls.Add(this.lblpassword);
            this.tabPage1.Controls.Add(this.txtpassword);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1307, 561);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "LOGIN";
            this.tabPage1.Enter += new System.EventHandler(this.tabPage1_Enter);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.SpringGreen;
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.lblplayermode);
            this.tabPage2.Controls.Add(this.btnadminplayerdelete);
            this.tabPage2.Controls.Add(this.btnadminplayerupdate);
            this.tabPage2.Controls.Add(this.btnadminplayeradd);
            this.tabPage2.Controls.Add(this.gridadminplayer);
            this.tabPage2.Controls.Add(this.lbladmintext);
            this.tabPage2.Controls.Add(this.lbladminvaluefilter);
            this.tabPage2.Controls.Add(this.cbadminvaluefilter);
            this.tabPage2.Controls.Add(this.lbladminnamefilter);
            this.tabPage2.Controls.Add(this.lbladmingoalfilter);
            this.tabPage2.Controls.Add(this.cbadminnamefilter);
            this.tabPage2.Controls.Add(this.cbadmingoalfilter);
            this.tabPage2.Controls.Add(this.btnadminnational);
            this.tabPage2.Controls.Add(this.btnadmincomp);
            this.tabPage2.Controls.Add(this.btnadminrecord);
            this.tabPage2.Controls.Add(this.btnadminmanager);
            this.tabPage2.Controls.Add(this.btnadminclub);
            this.tabPage2.Controls.Add(this.btnadminplayer);
            this.tabPage2.Controls.Add(this.txtadminplayer);
            this.tabPage2.Controls.Add(this.btnadminfilter);
            this.tabPage2.Controls.Add(this.lbladminpageswitch);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1307, 561);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "PLAYER";
            // 
            // lblplayermode
            // 
            this.lblplayermode.AutoSize = true;
            this.lblplayermode.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblplayermode.Location = new System.Drawing.Point(859, 57);
            this.lblplayermode.Name = "lblplayermode";
            this.lblplayermode.Size = new System.Drawing.Size(19, 21);
            this.lblplayermode.TabIndex = 39;
            this.lblplayermode.Text = "L";
            // 
            // btnadminplayerdelete
            // 
            this.btnadminplayerdelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminplayerdelete.Location = new System.Drawing.Point(737, 209);
            this.btnadminplayerdelete.Name = "btnadminplayerdelete";
            this.btnadminplayerdelete.Size = new System.Drawing.Size(75, 23);
            this.btnadminplayerdelete.TabIndex = 38;
            this.btnadminplayerdelete.Text = "DELETE";
            this.btnadminplayerdelete.UseVisualStyleBackColor = true;
            this.btnadminplayerdelete.Click += new System.EventHandler(this.btnadminplayerdelete_Click);
            // 
            // btnadminplayerupdate
            // 
            this.btnadminplayerupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminplayerupdate.Location = new System.Drawing.Point(737, 180);
            this.btnadminplayerupdate.Name = "btnadminplayerupdate";
            this.btnadminplayerupdate.Size = new System.Drawing.Size(75, 23);
            this.btnadminplayerupdate.TabIndex = 37;
            this.btnadminplayerupdate.Text = "UPDATE";
            this.btnadminplayerupdate.UseVisualStyleBackColor = true;
            this.btnadminplayerupdate.Click += new System.EventHandler(this.btnadminplayerupdate_Click);
            // 
            // btnadminplayeradd
            // 
            this.btnadminplayeradd.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminplayeradd.Location = new System.Drawing.Point(737, 150);
            this.btnadminplayeradd.Name = "btnadminplayeradd";
            this.btnadminplayeradd.Size = new System.Drawing.Size(75, 23);
            this.btnadminplayeradd.TabIndex = 36;
            this.btnadminplayeradd.Text = "ADD";
            this.btnadminplayeradd.UseVisualStyleBackColor = true;
            this.btnadminplayeradd.Click += new System.EventHandler(this.btnadminplayeradd_Click);
            // 
            // gridadminplayer
            // 
            this.gridadminplayer.AutoGenerateColumns = false;
            this.gridadminplayer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridadminplayer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.playerIDDataGridViewTextBoxColumn,
            this.playerJerseyNumDataGridViewTextBoxColumn,
            this.playerLnameDataGridViewTextBoxColumn,
            this.playerFnameDataGridViewTextBoxColumn,
            this.playerNatDataGridViewTextBoxColumn,
            this.playerDOBDataGridViewTextBoxColumn,
            this.playerHeightDataGridViewTextBoxColumn,
            this.playerWeightDataGridViewTextBoxColumn,
            this.playerGoalsDataGridViewTextBoxColumn,
            this.playerAssistsDataGridViewTextBoxColumn,
            this.playerPosDataGridViewTextBoxColumn,
            this.playerValUSDDataGridViewTextBoxColumn,
            this.natTeamCountryDataGridViewTextBoxColumn,
            this.clubClubIDDataGridViewTextBoxColumn});
            this.gridadminplayer.DataSource = this.playerBindingSource;
            this.gridadminplayer.Location = new System.Drawing.Point(41, 239);
            this.gridadminplayer.Name = "gridadminplayer";
            this.gridadminplayer.Size = new System.Drawing.Size(1063, 244);
            this.gridadminplayer.TabIndex = 35;
            // 
            // playerIDDataGridViewTextBoxColumn
            // 
            this.playerIDDataGridViewTextBoxColumn.DataPropertyName = "Player_ID";
            this.playerIDDataGridViewTextBoxColumn.HeaderText = "Player ID";
            this.playerIDDataGridViewTextBoxColumn.Name = "playerIDDataGridViewTextBoxColumn";
            // 
            // playerJerseyNumDataGridViewTextBoxColumn
            // 
            this.playerJerseyNumDataGridViewTextBoxColumn.DataPropertyName = "Player_Jersey_Num";
            this.playerJerseyNumDataGridViewTextBoxColumn.HeaderText = "Player Jersey Num";
            this.playerJerseyNumDataGridViewTextBoxColumn.Name = "playerJerseyNumDataGridViewTextBoxColumn";
            // 
            // playerLnameDataGridViewTextBoxColumn
            // 
            this.playerLnameDataGridViewTextBoxColumn.DataPropertyName = "Player_Lname";
            this.playerLnameDataGridViewTextBoxColumn.HeaderText = "Player Last Name";
            this.playerLnameDataGridViewTextBoxColumn.Name = "playerLnameDataGridViewTextBoxColumn";
            // 
            // playerFnameDataGridViewTextBoxColumn
            // 
            this.playerFnameDataGridViewTextBoxColumn.DataPropertyName = "Player_Fname";
            this.playerFnameDataGridViewTextBoxColumn.HeaderText = "Player First Name";
            this.playerFnameDataGridViewTextBoxColumn.Name = "playerFnameDataGridViewTextBoxColumn";
            // 
            // playerNatDataGridViewTextBoxColumn
            // 
            this.playerNatDataGridViewTextBoxColumn.DataPropertyName = "Player_Nat";
            this.playerNatDataGridViewTextBoxColumn.HeaderText = "Player Nationality";
            this.playerNatDataGridViewTextBoxColumn.Name = "playerNatDataGridViewTextBoxColumn";
            // 
            // playerDOBDataGridViewTextBoxColumn
            // 
            this.playerDOBDataGridViewTextBoxColumn.DataPropertyName = "Player_DOB";
            this.playerDOBDataGridViewTextBoxColumn.HeaderText = "Player DOB";
            this.playerDOBDataGridViewTextBoxColumn.Name = "playerDOBDataGridViewTextBoxColumn";
            // 
            // playerHeightDataGridViewTextBoxColumn
            // 
            this.playerHeightDataGridViewTextBoxColumn.DataPropertyName = "Player_Height";
            this.playerHeightDataGridViewTextBoxColumn.HeaderText = "Player Height";
            this.playerHeightDataGridViewTextBoxColumn.Name = "playerHeightDataGridViewTextBoxColumn";
            // 
            // playerWeightDataGridViewTextBoxColumn
            // 
            this.playerWeightDataGridViewTextBoxColumn.DataPropertyName = "Player_Weight";
            this.playerWeightDataGridViewTextBoxColumn.HeaderText = "Player Weight";
            this.playerWeightDataGridViewTextBoxColumn.Name = "playerWeightDataGridViewTextBoxColumn";
            // 
            // playerGoalsDataGridViewTextBoxColumn
            // 
            this.playerGoalsDataGridViewTextBoxColumn.DataPropertyName = "Player_Goals";
            this.playerGoalsDataGridViewTextBoxColumn.HeaderText = "Player Goals";
            this.playerGoalsDataGridViewTextBoxColumn.Name = "playerGoalsDataGridViewTextBoxColumn";
            // 
            // playerAssistsDataGridViewTextBoxColumn
            // 
            this.playerAssistsDataGridViewTextBoxColumn.DataPropertyName = "Player_Assists";
            this.playerAssistsDataGridViewTextBoxColumn.HeaderText = "Player Assists";
            this.playerAssistsDataGridViewTextBoxColumn.Name = "playerAssistsDataGridViewTextBoxColumn";
            // 
            // playerPosDataGridViewTextBoxColumn
            // 
            this.playerPosDataGridViewTextBoxColumn.DataPropertyName = "Player_Pos";
            this.playerPosDataGridViewTextBoxColumn.HeaderText = "Player Position";
            this.playerPosDataGridViewTextBoxColumn.Name = "playerPosDataGridViewTextBoxColumn";
            // 
            // playerValUSDDataGridViewTextBoxColumn
            // 
            this.playerValUSDDataGridViewTextBoxColumn.DataPropertyName = "Player_Val_USD";
            this.playerValUSDDataGridViewTextBoxColumn.HeaderText = "Player Value ($)";
            this.playerValUSDDataGridViewTextBoxColumn.Name = "playerValUSDDataGridViewTextBoxColumn";
            // 
            // natTeamCountryDataGridViewTextBoxColumn
            // 
            this.natTeamCountryDataGridViewTextBoxColumn.DataPropertyName = "Nat_Team_Country";
            this.natTeamCountryDataGridViewTextBoxColumn.HeaderText = "National Team Country";
            this.natTeamCountryDataGridViewTextBoxColumn.Name = "natTeamCountryDataGridViewTextBoxColumn";
            // 
            // clubClubIDDataGridViewTextBoxColumn
            // 
            this.clubClubIDDataGridViewTextBoxColumn.DataPropertyName = "Club_Club_ID";
            this.clubClubIDDataGridViewTextBoxColumn.HeaderText = "Club ID";
            this.clubClubIDDataGridViewTextBoxColumn.Name = "clubClubIDDataGridViewTextBoxColumn";
            // 
            // playerBindingSource
            // 
            this.playerBindingSource.DataMember = "player";
            this.playerBindingSource.DataSource = this.pldataDataSet;
            // 
            // pldataDataSet
            // 
            this.pldataDataSet.DataSetName = "pldataDataSet";
            this.pldataDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lbladmintext
            // 
            this.lbladmintext.AutoSize = true;
            this.lbladmintext.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladmintext.Location = new System.Drawing.Point(464, 131);
            this.lbladmintext.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbladmintext.Name = "lbladmintext";
            this.lbladmintext.Size = new System.Drawing.Size(126, 16);
            this.lbladmintext.TabIndex = 32;
            this.lbladmintext.Text = "SEARCH CRITERIA:";
            // 
            // lbladminvaluefilter
            // 
            this.lbladminvaluefilter.AutoSize = true;
            this.lbladminvaluefilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladminvaluefilter.Location = new System.Drawing.Point(540, 187);
            this.lbladminvaluefilter.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbladminvaluefilter.Name = "lbladminvaluefilter";
            this.lbladminvaluefilter.Size = new System.Drawing.Size(170, 16);
            this.lbladminvaluefilter.TabIndex = 31;
            this.lbladminvaluefilter.Text = "FILTER BY PLAYER VALUE:";
            // 
            // cbadminvaluefilter
            // 
            this.cbadminvaluefilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbadminvaluefilter.FormattingEnabled = true;
            this.cbadminvaluefilter.Items.AddRange(new object[] {
            "Highest to Lowest",
            "Lowest to Highest"});
            this.cbadminvaluefilter.Location = new System.Drawing.Point(558, 202);
            this.cbadminvaluefilter.Name = "cbadminvaluefilter";
            this.cbadminvaluefilter.Size = new System.Drawing.Size(121, 24);
            this.cbadminvaluefilter.TabIndex = 30;
            this.cbadminvaluefilter.SelectedIndexChanged += new System.EventHandler(this.cbadminvaluefilter_SelectedIndexChanged);
            // 
            // lbladminnamefilter
            // 
            this.lbladminnamefilter.AutoSize = true;
            this.lbladminnamefilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladminnamefilter.Location = new System.Drawing.Point(267, 187);
            this.lbladminnamefilter.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbladminnamefilter.Name = "lbladminnamefilter";
            this.lbladminnamefilter.Size = new System.Drawing.Size(121, 16);
            this.lbladminnamefilter.TabIndex = 29;
            this.lbladminnamefilter.Text = "FILTER BY NAMES:";
            // 
            // lbladmingoalfilter
            // 
            this.lbladmingoalfilter.AutoSize = true;
            this.lbladmingoalfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladmingoalfilter.Location = new System.Drawing.Point(415, 187);
            this.lbladmingoalfilter.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbladmingoalfilter.Name = "lbladmingoalfilter";
            this.lbladmingoalfilter.Size = new System.Drawing.Size(119, 16);
            this.lbladmingoalfilter.TabIndex = 28;
            this.lbladmingoalfilter.Text = "FILTER BY GOALS:";
            // 
            // cbadminnamefilter
            // 
            this.cbadminnamefilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbadminnamefilter.FormattingEnabled = true;
            this.cbadminnamefilter.Items.AddRange(new object[] {
            "Last Name: A-Z",
            "Last Name: Z-A"});
            this.cbadminnamefilter.Location = new System.Drawing.Point(267, 202);
            this.cbadminnamefilter.Name = "cbadminnamefilter";
            this.cbadminnamefilter.Size = new System.Drawing.Size(121, 24);
            this.cbadminnamefilter.TabIndex = 26;
            this.cbadminnamefilter.SelectedIndexChanged += new System.EventHandler(this.cbadminnamefilter_SelectedIndexChanged);
            // 
            // cbadmingoalfilter
            // 
            this.cbadmingoalfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbadmingoalfilter.FormattingEnabled = true;
            this.cbadmingoalfilter.Items.AddRange(new object[] {
            "Most Goals",
            "Least Goals"});
            this.cbadmingoalfilter.Location = new System.Drawing.Point(410, 202);
            this.cbadmingoalfilter.Name = "cbadmingoalfilter";
            this.cbadmingoalfilter.Size = new System.Drawing.Size(121, 24);
            this.cbadmingoalfilter.TabIndex = 25;
            this.cbadmingoalfilter.SelectedIndexChanged += new System.EventHandler(this.cbadmingoalfilter_SelectedIndexChanged);
            // 
            // btnadminnational
            // 
            this.btnadminnational.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminnational.Location = new System.Drawing.Point(665, 74);
            this.btnadminnational.Name = "btnadminnational";
            this.btnadminnational.Size = new System.Drawing.Size(125, 23);
            this.btnadminnational.TabIndex = 24;
            this.btnadminnational.Text = "NATIONAL TEAM";
            this.btnadminnational.UseVisualStyleBackColor = true;
            this.btnadminnational.Click += new System.EventHandler(this.btnadminnational_Click);
            // 
            // btnadmincomp
            // 
            this.btnadmincomp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadmincomp.Location = new System.Drawing.Point(665, 35);
            this.btnadmincomp.Name = "btnadmincomp";
            this.btnadmincomp.Size = new System.Drawing.Size(125, 23);
            this.btnadmincomp.TabIndex = 23;
            this.btnadmincomp.Text = "COMPETITION";
            this.btnadmincomp.UseVisualStyleBackColor = true;
            this.btnadmincomp.Click += new System.EventHandler(this.btnadmincomp_Click);
            // 
            // btnadminrecord
            // 
            this.btnadminrecord.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminrecord.Location = new System.Drawing.Point(574, 73);
            this.btnadminrecord.Name = "btnadminrecord";
            this.btnadminrecord.Size = new System.Drawing.Size(75, 23);
            this.btnadminrecord.TabIndex = 22;
            this.btnadminrecord.Text = "HISTORY";
            this.btnadminrecord.UseVisualStyleBackColor = true;
            this.btnadminrecord.Click += new System.EventHandler(this.btnadminrecord_Click);
            // 
            // btnadminmanager
            // 
            this.btnadminmanager.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminmanager.Location = new System.Drawing.Point(473, 73);
            this.btnadminmanager.Name = "btnadminmanager";
            this.btnadminmanager.Size = new System.Drawing.Size(84, 23);
            this.btnadminmanager.TabIndex = 21;
            this.btnadminmanager.Text = "MANAGER";
            this.btnadminmanager.UseVisualStyleBackColor = true;
            this.btnadminmanager.Click += new System.EventHandler(this.btnadminmanager_Click);
            // 
            // btnadminclub
            // 
            this.btnadminclub.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminclub.Location = new System.Drawing.Point(574, 34);
            this.btnadminclub.Name = "btnadminclub";
            this.btnadminclub.Size = new System.Drawing.Size(75, 23);
            this.btnadminclub.TabIndex = 20;
            this.btnadminclub.Text = "CLUB";
            this.btnadminclub.UseVisualStyleBackColor = true;
            this.btnadminclub.Click += new System.EventHandler(this.btnadminclub_Click);
            // 
            // btnadminplayer
            // 
            this.btnadminplayer.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminplayer.Location = new System.Drawing.Point(473, 34);
            this.btnadminplayer.Name = "btnadminplayer";
            this.btnadminplayer.Size = new System.Drawing.Size(75, 23);
            this.btnadminplayer.TabIndex = 19;
            this.btnadminplayer.Text = "PLAYER";
            this.btnadminplayer.UseVisualStyleBackColor = true;
            this.btnadminplayer.Click += new System.EventHandler(this.btnadminplayer_Click);
            // 
            // txtadminplayer
            // 
            this.txtadminplayer.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadminplayer.Location = new System.Drawing.Point(337, 147);
            this.txtadminplayer.Name = "txtadminplayer";
            this.txtadminplayer.Size = new System.Drawing.Size(368, 23);
            this.txtadminplayer.TabIndex = 18;
            // 
            // btnadminfilter
            // 
            this.btnadminfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminfilter.Location = new System.Drawing.Point(872, 147);
            this.btnadminfilter.Name = "btnadminfilter";
            this.btnadminfilter.Size = new System.Drawing.Size(131, 76);
            this.btnadminfilter.TabIndex = 17;
            this.btnadminfilter.Text = "FILTER";
            this.btnadminfilter.UseVisualStyleBackColor = true;
            this.btnadminfilter.Click += new System.EventHandler(this.btnadminfilter_Click);
            // 
            // lbladminpageswitch
            // 
            this.lbladminpageswitch.AutoSize = true;
            this.lbladminpageswitch.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladminpageswitch.Location = new System.Drawing.Point(388, 57);
            this.lbladminpageswitch.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbladminpageswitch.Name = "lbladminpageswitch";
            this.lbladminpageswitch.Size = new System.Drawing.Size(92, 16);
            this.lbladminpageswitch.TabIndex = 16;
            this.lbladminpageswitch.Text = "SEARCH FOR:";
            this.lbladminpageswitch.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(90, 57);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(191, 107);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.MinimumSize = new System.Drawing.Size(5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(389, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "PREMIER LEAGUE PLAYER DATABASE";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkOrange;
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.pictureBox8);
            this.tabPage3.Controls.Add(this.btnaddplayer);
            this.tabPage3.Controls.Add(this.lblplayeradd);
            this.tabPage3.Controls.Add(this.lbltitleadd);
            this.tabPage3.Controls.Add(this.lblat14);
            this.tabPage3.Controls.Add(this.lblat13);
            this.tabPage3.Controls.Add(this.lblat12);
            this.tabPage3.Controls.Add(this.lblat11);
            this.tabPage3.Controls.Add(this.lblat10);
            this.tabPage3.Controls.Add(this.lblat9);
            this.tabPage3.Controls.Add(this.lblat8);
            this.tabPage3.Controls.Add(this.lblat7);
            this.tabPage3.Controls.Add(this.lblat6);
            this.tabPage3.Controls.Add(this.lblat5);
            this.tabPage3.Controls.Add(this.lblat4);
            this.tabPage3.Controls.Add(this.lblat3);
            this.tabPage3.Controls.Add(this.lblat2);
            this.tabPage3.Controls.Add(this.lblat1);
            this.tabPage3.Controls.Add(this.txtat14);
            this.tabPage3.Controls.Add(this.txtat13);
            this.tabPage3.Controls.Add(this.txtat12);
            this.tabPage3.Controls.Add(this.txtat11);
            this.tabPage3.Controls.Add(this.txtat10);
            this.tabPage3.Controls.Add(this.txtat9);
            this.tabPage3.Controls.Add(this.txtat8);
            this.tabPage3.Controls.Add(this.txtat7);
            this.tabPage3.Controls.Add(this.txtat6);
            this.tabPage3.Controls.Add(this.txtat5);
            this.tabPage3.Controls.Add(this.txtat4);
            this.tabPage3.Controls.Add(this.txtat3);
            this.tabPage3.Controls.Add(this.txtat2);
            this.tabPage3.Controls.Add(this.txtat1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1140, 561);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "ADD";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(303, 79);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(144, 21);
            this.label38.TabIndex = 40;
            this.label38.Text = "ADD ENTRY PAGE";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(727, 47);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(191, 107);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 31;
            this.pictureBox8.TabStop = false;
            // 
            // btnaddplayer
            // 
            this.btnaddplayer.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddplayer.Location = new System.Drawing.Point(307, 349);
            this.btnaddplayer.Name = "btnaddplayer";
            this.btnaddplayer.Size = new System.Drawing.Size(131, 76);
            this.btnaddplayer.TabIndex = 30;
            this.btnaddplayer.Text = "ADD PLAYER";
            this.btnaddplayer.UseVisualStyleBackColor = true;
            this.btnaddplayer.Click += new System.EventHandler(this.btnaddplayer_Click);
            // 
            // lblplayeradd
            // 
            this.lblplayeradd.AutoSize = true;
            this.lblplayeradd.Location = new System.Drawing.Point(913, 443);
            this.lblplayeradd.MinimumSize = new System.Drawing.Size(5, 0);
            this.lblplayeradd.Name = "lblplayeradd";
            this.lblplayeradd.Size = new System.Drawing.Size(5, 13);
            this.lblplayeradd.TabIndex = 29;
            // 
            // lbltitleadd
            // 
            this.lbltitleadd.AutoSize = true;
            this.lbltitleadd.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitleadd.Location = new System.Drawing.Point(228, 47);
            this.lbltitleadd.MinimumSize = new System.Drawing.Size(5, 0);
            this.lbltitleadd.Name = "lbltitleadd";
            this.lbltitleadd.Size = new System.Drawing.Size(305, 25);
            this.lbltitleadd.TabIndex = 28;
            this.lbltitleadd.Text = "PREMIER LEAGUE DATABASE";
            // 
            // lblat14
            // 
            this.lblat14.AutoSize = true;
            this.lblat14.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat14.Location = new System.Drawing.Point(379, 294);
            this.lblat14.Name = "lblat14";
            this.lblat14.Size = new System.Drawing.Size(62, 16);
            this.lblat14.TabIndex = 27;
            this.lblat14.Text = "CLUB ID:";
            // 
            // lblat13
            // 
            this.lblat13.AutoSize = true;
            this.lblat13.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat13.Location = new System.Drawing.Point(379, 264);
            this.lblat13.Name = "lblat13";
            this.lblat13.Size = new System.Drawing.Size(117, 16);
            this.lblat13.TabIndex = 26;
            this.lblat13.Text = "NATIONAL TEAM:";
            // 
            // lblat12
            // 
            this.lblat12.AutoSize = true;
            this.lblat12.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat12.Location = new System.Drawing.Point(379, 238);
            this.lblat12.Name = "lblat12";
            this.lblat12.Size = new System.Drawing.Size(143, 16);
            this.lblat12.TabIndex = 25;
            this.lblat12.Text = "PLAYER VALUE (USD):";
            // 
            // lblat11
            // 
            this.lblat11.AutoSize = true;
            this.lblat11.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat11.Location = new System.Drawing.Point(379, 216);
            this.lblat11.Name = "lblat11";
            this.lblat11.Size = new System.Drawing.Size(122, 16);
            this.lblat11.TabIndex = 24;
            this.lblat11.Text = "PLAYER POSITION:";
            // 
            // lblat10
            // 
            this.lblat10.AutoSize = true;
            this.lblat10.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat10.Location = new System.Drawing.Point(379, 190);
            this.lblat10.Name = "lblat10";
            this.lblat10.Size = new System.Drawing.Size(139, 16);
            this.lblat10.TabIndex = 23;
            this.lblat10.Text = "NUMBER OF ASSISTS:";
            // 
            // lblat9
            // 
            this.lblat9.AutoSize = true;
            this.lblat9.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat9.Location = new System.Drawing.Point(379, 160);
            this.lblat9.Name = "lblat9";
            this.lblat9.Size = new System.Drawing.Size(133, 16);
            this.lblat9.TabIndex = 22;
            this.lblat9.Text = "NUMBER OF GOALS:";
            // 
            // lblat8
            // 
            this.lblat8.AutoSize = true;
            this.lblat8.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat8.Location = new System.Drawing.Point(379, 134);
            this.lblat8.Name = "lblat8";
            this.lblat8.Size = new System.Drawing.Size(115, 16);
            this.lblat8.TabIndex = 21;
            this.lblat8.Text = "PLAYER WEIGHT:";
            // 
            // lblat7
            // 
            this.lblat7.AutoSize = true;
            this.lblat7.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat7.Location = new System.Drawing.Point(6, 294);
            this.lblat7.Name = "lblat7";
            this.lblat7.Size = new System.Drawing.Size(112, 16);
            this.lblat7.TabIndex = 20;
            this.lblat7.Text = "PLAYER HEIGHT:";
            // 
            // lblat6
            // 
            this.lblat6.AutoSize = true;
            this.lblat6.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat6.Location = new System.Drawing.Point(6, 264);
            this.lblat6.Name = "lblat6";
            this.lblat6.Size = new System.Drawing.Size(90, 16);
            this.lblat6.TabIndex = 19;
            this.lblat6.Text = "PLAYER DOB:";
            // 
            // lblat5
            // 
            this.lblat5.AutoSize = true;
            this.lblat5.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat5.Location = new System.Drawing.Point(6, 238);
            this.lblat5.Name = "lblat5";
            this.lblat5.Size = new System.Drawing.Size(149, 16);
            this.lblat5.TabIndex = 18;
            this.lblat5.Text = "PLAYER NATIONALITY:";
            // 
            // lblat4
            // 
            this.lblat4.AutoSize = true;
            this.lblat4.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat4.Location = new System.Drawing.Point(6, 212);
            this.lblat4.Name = "lblat4";
            this.lblat4.Size = new System.Drawing.Size(138, 16);
            this.lblat4.TabIndex = 17;
            this.lblat4.Text = "PLAYER FIRST NAME:";
            // 
            // lblat3
            // 
            this.lblat3.AutoSize = true;
            this.lblat3.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat3.Location = new System.Drawing.Point(7, 186);
            this.lblat3.Name = "lblat3";
            this.lblat3.Size = new System.Drawing.Size(134, 16);
            this.lblat3.TabIndex = 16;
            this.lblat3.Text = "PLAYER LAST NAME:";
            // 
            // lblat2
            // 
            this.lblat2.AutoSize = true;
            this.lblat2.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat2.Location = new System.Drawing.Point(6, 160);
            this.lblat2.Name = "lblat2";
            this.lblat2.Size = new System.Drawing.Size(141, 16);
            this.lblat2.TabIndex = 15;
            this.lblat2.Text = "PLAYER KIT NUMBER:";
            // 
            // lblat1
            // 
            this.lblat1.AutoSize = true;
            this.lblat1.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblat1.Location = new System.Drawing.Point(6, 134);
            this.lblat1.Name = "lblat1";
            this.lblat1.Size = new System.Drawing.Size(76, 16);
            this.lblat1.TabIndex = 14;
            this.lblat1.Text = "PLAYER ID:";
            // 
            // txtat14
            // 
            this.txtat14.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat14.Location = new System.Drawing.Point(565, 287);
            this.txtat14.Name = "txtat14";
            this.txtat14.Size = new System.Drawing.Size(100, 23);
            this.txtat14.TabIndex = 13;
            // 
            // txtat13
            // 
            this.txtat13.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat13.Location = new System.Drawing.Point(565, 261);
            this.txtat13.Name = "txtat13";
            this.txtat13.Size = new System.Drawing.Size(100, 23);
            this.txtat13.TabIndex = 12;
            // 
            // txtat12
            // 
            this.txtat12.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat12.Location = new System.Drawing.Point(565, 235);
            this.txtat12.Name = "txtat12";
            this.txtat12.Size = new System.Drawing.Size(100, 23);
            this.txtat12.TabIndex = 11;
            // 
            // txtat11
            // 
            this.txtat11.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat11.Location = new System.Drawing.Point(565, 209);
            this.txtat11.Name = "txtat11";
            this.txtat11.Size = new System.Drawing.Size(100, 23);
            this.txtat11.TabIndex = 10;
            // 
            // txtat10
            // 
            this.txtat10.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat10.Location = new System.Drawing.Point(565, 183);
            this.txtat10.Name = "txtat10";
            this.txtat10.Size = new System.Drawing.Size(100, 23);
            this.txtat10.TabIndex = 9;
            // 
            // txtat9
            // 
            this.txtat9.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat9.Location = new System.Drawing.Point(565, 157);
            this.txtat9.Name = "txtat9";
            this.txtat9.Size = new System.Drawing.Size(100, 23);
            this.txtat9.TabIndex = 8;
            // 
            // txtat8
            // 
            this.txtat8.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat8.Location = new System.Drawing.Point(565, 131);
            this.txtat8.Name = "txtat8";
            this.txtat8.Size = new System.Drawing.Size(100, 23);
            this.txtat8.TabIndex = 7;
            // 
            // txtat7
            // 
            this.txtat7.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat7.Location = new System.Drawing.Point(256, 287);
            this.txtat7.Name = "txtat7";
            this.txtat7.Size = new System.Drawing.Size(100, 23);
            this.txtat7.TabIndex = 6;
            // 
            // txtat6
            // 
            this.txtat6.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat6.Location = new System.Drawing.Point(256, 261);
            this.txtat6.Name = "txtat6";
            this.txtat6.Size = new System.Drawing.Size(100, 23);
            this.txtat6.TabIndex = 5;
            // 
            // txtat5
            // 
            this.txtat5.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat5.Location = new System.Drawing.Point(256, 235);
            this.txtat5.Name = "txtat5";
            this.txtat5.Size = new System.Drawing.Size(100, 23);
            this.txtat5.TabIndex = 4;
            // 
            // txtat4
            // 
            this.txtat4.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat4.Location = new System.Drawing.Point(256, 209);
            this.txtat4.Name = "txtat4";
            this.txtat4.Size = new System.Drawing.Size(100, 23);
            this.txtat4.TabIndex = 3;
            this.txtat4.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtat3
            // 
            this.txtat3.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat3.Location = new System.Drawing.Point(256, 183);
            this.txtat3.Name = "txtat3";
            this.txtat3.Size = new System.Drawing.Size(100, 23);
            this.txtat3.TabIndex = 2;
            // 
            // txtat2
            // 
            this.txtat2.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat2.Location = new System.Drawing.Point(256, 157);
            this.txtat2.Name = "txtat2";
            this.txtat2.Size = new System.Drawing.Size(100, 23);
            this.txtat2.TabIndex = 1;
            // 
            // txtat1
            // 
            this.txtat1.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtat1.Location = new System.Drawing.Point(256, 131);
            this.txtat1.Name = "txtat1";
            this.txtat1.Size = new System.Drawing.Size(100, 23);
            this.txtat1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Violet;
            this.tabPage4.Controls.Add(this.label39);
            this.tabPage4.Controls.Add(this.pictureBox9);
            this.tabPage4.Controls.Add(this.txtdelete1);
            this.tabPage4.Controls.Add(this.lbldelete1);
            this.tabPage4.Controls.Add(this.btndeleteplayer);
            this.tabPage4.Controls.Add(this.txtdelete);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.lbldelete);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1140, 561);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "DELETE";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(404, 73);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(167, 21);
            this.label39.TabIndex = 40;
            this.label39.Text = "DELETE ENTRY PAGE";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(65, 73);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(191, 107);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 34;
            this.pictureBox9.TabStop = false;
            // 
            // txtdelete1
            // 
            this.txtdelete1.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdelete1.Location = new System.Drawing.Point(572, 183);
            this.txtdelete1.Name = "txtdelete1";
            this.txtdelete1.Size = new System.Drawing.Size(100, 23);
            this.txtdelete1.TabIndex = 33;
            this.txtdelete1.Visible = false;
            // 
            // lbldelete1
            // 
            this.lbldelete1.AutoSize = true;
            this.lbldelete1.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldelete1.Location = new System.Drawing.Point(358, 187);
            this.lbldelete1.Name = "lbldelete1";
            this.lbldelete1.Size = new System.Drawing.Size(129, 16);
            this.lbldelete1.TabIndex = 32;
            this.lbldelete1.Text = "TEAM START DATE:";
            // 
            // btndeleteplayer
            // 
            this.btndeleteplayer.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeleteplayer.Location = new System.Drawing.Point(408, 247);
            this.btndeleteplayer.Name = "btndeleteplayer";
            this.btndeleteplayer.Size = new System.Drawing.Size(131, 76);
            this.btndeleteplayer.TabIndex = 31;
            this.btndeleteplayer.Text = "DELETE";
            this.btndeleteplayer.UseVisualStyleBackColor = true;
            this.btndeleteplayer.Click += new System.EventHandler(this.btndeleteplayer_Click);
            // 
            // txtdelete
            // 
            this.txtdelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdelete.Location = new System.Drawing.Point(572, 154);
            this.txtdelete.Name = "txtdelete";
            this.txtdelete.Size = new System.Drawing.Size(100, 23);
            this.txtdelete.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(332, 41);
            this.label3.MinimumSize = new System.Drawing.Size(5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(305, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "PREMIER LEAGUE DATABASE";
            // 
            // lbldelete
            // 
            this.lbldelete.AutoSize = true;
            this.lbldelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldelete.Location = new System.Drawing.Point(358, 161);
            this.lbldelete.Name = "lbldelete";
            this.lbldelete.Size = new System.Drawing.Size(76, 16);
            this.lbldelete.TabIndex = 15;
            this.lbldelete.Text = "PLAYER ID:";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Tomato;
            this.tabPage5.Controls.Add(this.label40);
            this.tabPage5.Controls.Add(this.pictureBox10);
            this.tabPage5.Controls.Add(this.txtupdatestart);
            this.tabPage5.Controls.Add(this.lblupdatestart);
            this.tabPage5.Controls.Add(this.txtvalupdate);
            this.tabPage5.Controls.Add(this.lblvalnew);
            this.tabPage5.Controls.Add(this.txtupdateID);
            this.tabPage5.Controls.Add(this.lblupdateID);
            this.tabPage5.Controls.Add(this.btnupdate);
            this.tabPage5.Controls.Add(this.txtupdateatt);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.lblupdateatt);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1140, 561);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "UPDATE";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(434, 87);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(171, 21);
            this.label40.TabIndex = 43;
            this.label40.Text = "UPDATE ENTRY PAGE";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(15, 78);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(191, 107);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 42;
            this.pictureBox10.TabStop = false;
            // 
            // txtupdatestart
            // 
            this.txtupdatestart.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtupdatestart.Location = new System.Drawing.Point(749, 209);
            this.txtupdatestart.Name = "txtupdatestart";
            this.txtupdatestart.Size = new System.Drawing.Size(100, 23);
            this.txtupdatestart.TabIndex = 41;
            // 
            // lblupdatestart
            // 
            this.lblupdatestart.AutoSize = true;
            this.lblupdatestart.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdatestart.Location = new System.Drawing.Point(544, 212);
            this.lblupdatestart.Name = "lblupdatestart";
            this.lblupdatestart.Size = new System.Drawing.Size(129, 16);
            this.lblupdatestart.TabIndex = 40;
            this.lblupdatestart.Text = "TEAM START DATE:";
            // 
            // txtvalupdate
            // 
            this.txtvalupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvalupdate.Location = new System.Drawing.Point(428, 207);
            this.txtvalupdate.Name = "txtvalupdate";
            this.txtvalupdate.Size = new System.Drawing.Size(100, 23);
            this.txtvalupdate.TabIndex = 39;
            // 
            // lblvalnew
            // 
            this.lblvalnew.AutoSize = true;
            this.lblvalnew.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvalnew.Location = new System.Drawing.Point(231, 214);
            this.lblvalnew.Name = "lblvalnew";
            this.lblvalnew.Size = new System.Drawing.Size(130, 16);
            this.lblvalnew.TabIndex = 38;
            this.lblvalnew.Text = "UPDATE VALUE TO:";
            // 
            // txtupdateID
            // 
            this.txtupdateID.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtupdateID.Location = new System.Drawing.Point(428, 161);
            this.txtupdateID.Name = "txtupdateID";
            this.txtupdateID.Size = new System.Drawing.Size(100, 23);
            this.txtupdateID.TabIndex = 37;
            // 
            // lblupdateID
            // 
            this.lblupdateID.AutoSize = true;
            this.lblupdateID.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdateID.Location = new System.Drawing.Point(231, 164);
            this.lblupdateID.Name = "lblupdateID";
            this.lblupdateID.Size = new System.Drawing.Size(76, 16);
            this.lblupdateID.TabIndex = 36;
            this.lblupdateID.Text = "PLAYER ID:";
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(438, 275);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(131, 76);
            this.btnupdate.TabIndex = 35;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // txtupdateatt
            // 
            this.txtupdateatt.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtupdateatt.Location = new System.Drawing.Point(749, 163);
            this.txtupdateatt.Name = "txtupdateatt";
            this.txtupdateatt.Size = new System.Drawing.Size(100, 23);
            this.txtupdateatt.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(368, 41);
            this.label2.MinimumSize = new System.Drawing.Size(5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(305, 25);
            this.label2.TabIndex = 33;
            this.label2.Text = "PREMIER LEAGUE DATABASE";
            // 
            // lblupdateatt
            // 
            this.lblupdateatt.AutoSize = true;
            this.lblupdateatt.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdateatt.Location = new System.Drawing.Point(544, 166);
            this.lblupdateatt.Name = "lblupdateatt";
            this.lblupdateatt.Size = new System.Drawing.Size(163, 16);
            this.lblupdateatt.TabIndex = 32;
            this.lblupdateatt.Text = "ATTRIBUTE TO CHANGE:";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.YellowGreen;
            this.tabPage6.Controls.Add(this.lblclubmode);
            this.tabPage6.Controls.Add(this.btnclub2player);
            this.tabPage6.Controls.Add(this.gridclub);
            this.tabPage6.Controls.Add(this.label10);
            this.tabPage6.Controls.Add(this.btnclubdelete);
            this.tabPage6.Controls.Add(this.btnclubupdate);
            this.tabPage6.Controls.Add(this.btnclubadd);
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.Controls.Add(this.clubfiltercap);
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Controls.Add(this.label7);
            this.tabPage6.Controls.Add(this.clubfiltername);
            this.tabPage6.Controls.Add(this.clubfiltercity);
            this.tabPage6.Controls.Add(this.btnclub2nat);
            this.tabPage6.Controls.Add(this.btnclub2comp);
            this.tabPage6.Controls.Add(this.button6);
            this.tabPage6.Controls.Add(this.btnclub2man);
            this.tabPage6.Controls.Add(this.button8);
            this.tabPage6.Controls.Add(this.txtsearchclub);
            this.tabPage6.Controls.Add(this.btnfilterclub);
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.pictureBox3);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1140, 561);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "CLUB";
            // 
            // lblclubmode
            // 
            this.lblclubmode.AutoSize = true;
            this.lblclubmode.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblclubmode.Location = new System.Drawing.Point(871, 65);
            this.lblclubmode.Name = "lblclubmode";
            this.lblclubmode.Size = new System.Drawing.Size(19, 21);
            this.lblclubmode.TabIndex = 64;
            this.lblclubmode.Text = "L";
            // 
            // btnclub2player
            // 
            this.btnclub2player.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclub2player.Location = new System.Drawing.Point(445, 32);
            this.btnclub2player.Name = "btnclub2player";
            this.btnclub2player.Size = new System.Drawing.Size(75, 23);
            this.btnclub2player.TabIndex = 63;
            this.btnclub2player.Text = "PLAYER";
            this.btnclub2player.UseVisualStyleBackColor = true;
            this.btnclub2player.Click += new System.EventHandler(this.btnclub2player_Click);
            // 
            // gridclub
            // 
            this.gridclub.AutoGenerateColumns = false;
            this.gridclub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridclub.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clubIDDataGridViewTextBoxColumn,
            this.clubNameDataGridViewTextBoxColumn,
            this.clubStadiumDataGridViewTextBoxColumn,
            this.clubCityDataGridViewTextBoxColumn,
            this.clubCapacityDataGridViewTextBoxColumn,
            this.managerManIDDataGridViewTextBoxColumn});
            this.gridclub.DataSource = this.clubBindingSource;
            this.gridclub.Location = new System.Drawing.Point(175, 221);
            this.gridclub.Name = "gridclub";
            this.gridclub.Size = new System.Drawing.Size(674, 272);
            this.gridclub.TabIndex = 62;
            // 
            // clubIDDataGridViewTextBoxColumn
            // 
            this.clubIDDataGridViewTextBoxColumn.DataPropertyName = "Club_ID";
            this.clubIDDataGridViewTextBoxColumn.HeaderText = "Club_ID";
            this.clubIDDataGridViewTextBoxColumn.Name = "clubIDDataGridViewTextBoxColumn";
            // 
            // clubNameDataGridViewTextBoxColumn
            // 
            this.clubNameDataGridViewTextBoxColumn.DataPropertyName = "Club_Name";
            this.clubNameDataGridViewTextBoxColumn.HeaderText = "Club_Name";
            this.clubNameDataGridViewTextBoxColumn.Name = "clubNameDataGridViewTextBoxColumn";
            // 
            // clubStadiumDataGridViewTextBoxColumn
            // 
            this.clubStadiumDataGridViewTextBoxColumn.DataPropertyName = "Club_Stadium";
            this.clubStadiumDataGridViewTextBoxColumn.HeaderText = "Club_Stadium";
            this.clubStadiumDataGridViewTextBoxColumn.Name = "clubStadiumDataGridViewTextBoxColumn";
            // 
            // clubCityDataGridViewTextBoxColumn
            // 
            this.clubCityDataGridViewTextBoxColumn.DataPropertyName = "Club_City";
            this.clubCityDataGridViewTextBoxColumn.HeaderText = "Club_City";
            this.clubCityDataGridViewTextBoxColumn.Name = "clubCityDataGridViewTextBoxColumn";
            // 
            // clubCapacityDataGridViewTextBoxColumn
            // 
            this.clubCapacityDataGridViewTextBoxColumn.DataPropertyName = "Club_Capacity";
            this.clubCapacityDataGridViewTextBoxColumn.HeaderText = "Club_Capacity";
            this.clubCapacityDataGridViewTextBoxColumn.Name = "clubCapacityDataGridViewTextBoxColumn";
            // 
            // managerManIDDataGridViewTextBoxColumn
            // 
            this.managerManIDDataGridViewTextBoxColumn.DataPropertyName = "Manager_Man_ID";
            this.managerManIDDataGridViewTextBoxColumn.HeaderText = "Manager_Man_ID";
            this.managerManIDDataGridViewTextBoxColumn.Name = "managerManIDDataGridViewTextBoxColumn";
            // 
            // clubBindingSource
            // 
            this.clubBindingSource.DataMember = "club";
            this.clubBindingSource.DataSource = this.pldataDataSet1;
            // 
            // pldataDataSet1
            // 
            this.pldataDataSet1.DataSetName = "pldataDataSet";
            this.pldataDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(506, 173);
            this.label10.MinimumSize = new System.Drawing.Size(5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(201, 16);
            this.label10.TabIndex = 61;
            this.label10.Text = "FILTER BY STADIUM CAPACITY:";
            // 
            // btnclubdelete
            // 
            this.btnclubdelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclubdelete.Location = new System.Drawing.Point(727, 163);
            this.btnclubdelete.Name = "btnclubdelete";
            this.btnclubdelete.Size = new System.Drawing.Size(75, 23);
            this.btnclubdelete.TabIndex = 60;
            this.btnclubdelete.Text = "DELETE";
            this.btnclubdelete.UseVisualStyleBackColor = true;
            this.btnclubdelete.Click += new System.EventHandler(this.btndeleteclub_Click);
            // 
            // btnclubupdate
            // 
            this.btnclubupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclubupdate.Location = new System.Drawing.Point(727, 134);
            this.btnclubupdate.Name = "btnclubupdate";
            this.btnclubupdate.Size = new System.Drawing.Size(75, 23);
            this.btnclubupdate.TabIndex = 59;
            this.btnclubupdate.Text = "UPDATE";
            this.btnclubupdate.UseVisualStyleBackColor = true;
            this.btnclubupdate.Click += new System.EventHandler(this.btnclubupdate_Click);
            // 
            // btnclubadd
            // 
            this.btnclubadd.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclubadd.Location = new System.Drawing.Point(727, 104);
            this.btnclubadd.Name = "btnclubadd";
            this.btnclubadd.Size = new System.Drawing.Size(75, 23);
            this.btnclubadd.TabIndex = 58;
            this.btnclubadd.Text = "ADD";
            this.btnclubadd.UseVisualStyleBackColor = true;
            this.btnclubadd.Click += new System.EventHandler(this.btnclubadd_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(395, 120);
            this.label4.MinimumSize = new System.Drawing.Size(5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 16);
            this.label4.TabIndex = 56;
            this.label4.Text = "SEARCH CRITERIA:";
            // 
            // clubfiltercap
            // 
            this.clubfiltercap.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clubfiltercap.FormattingEnabled = true;
            this.clubfiltercap.Items.AddRange(new object[] {
            "Highest to Lowest",
            "Lowest to Highest"});
            this.clubfiltercap.Location = new System.Drawing.Point(529, 189);
            this.clubfiltercap.Name = "clubfiltercap";
            this.clubfiltercap.Size = new System.Drawing.Size(121, 24);
            this.clubfiltercap.TabIndex = 54;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(235, 173);
            this.label6.MinimumSize = new System.Drawing.Size(5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "FILTER BY NAME:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(395, 173);
            this.label7.MinimumSize = new System.Drawing.Size(5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 16);
            this.label7.TabIndex = 52;
            this.label7.Text = "FILTER BY CITY:";
            // 
            // clubfiltername
            // 
            this.clubfiltername.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clubfiltername.FormattingEnabled = true;
            this.clubfiltername.Items.AddRange(new object[] {
            "Club Name: A-Z",
            "Club Name: Z-A"});
            this.clubfiltername.Location = new System.Drawing.Point(238, 189);
            this.clubfiltername.Name = "clubfiltername";
            this.clubfiltername.Size = new System.Drawing.Size(121, 24);
            this.clubfiltername.TabIndex = 51;
            // 
            // clubfiltercity
            // 
            this.clubfiltercity.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clubfiltercity.FormattingEnabled = true;
            this.clubfiltercity.Items.AddRange(new object[] {
            "City Name: A-Z",
            "City Name: Z-A"});
            this.clubfiltercity.Location = new System.Drawing.Point(381, 189);
            this.clubfiltercity.Name = "clubfiltercity";
            this.clubfiltercity.Size = new System.Drawing.Size(121, 24);
            this.clubfiltercity.TabIndex = 50;
            // 
            // btnclub2nat
            // 
            this.btnclub2nat.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclub2nat.Location = new System.Drawing.Point(637, 72);
            this.btnclub2nat.Name = "btnclub2nat";
            this.btnclub2nat.Size = new System.Drawing.Size(125, 23);
            this.btnclub2nat.TabIndex = 49;
            this.btnclub2nat.Text = "NATIONAL TEAM";
            this.btnclub2nat.UseVisualStyleBackColor = true;
            this.btnclub2nat.Click += new System.EventHandler(this.btnclub2nat_Click);
            // 
            // btnclub2comp
            // 
            this.btnclub2comp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclub2comp.Location = new System.Drawing.Point(637, 33);
            this.btnclub2comp.Name = "btnclub2comp";
            this.btnclub2comp.Size = new System.Drawing.Size(125, 23);
            this.btnclub2comp.TabIndex = 48;
            this.btnclub2comp.Text = "COMPETITION";
            this.btnclub2comp.UseVisualStyleBackColor = true;
            this.btnclub2comp.Click += new System.EventHandler(this.btnclub2comp_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(546, 71);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 47;
            this.button6.Text = "HISTORY";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnclub2man
            // 
            this.btnclub2man.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclub2man.Location = new System.Drawing.Point(445, 71);
            this.btnclub2man.Name = "btnclub2man";
            this.btnclub2man.Size = new System.Drawing.Size(95, 23);
            this.btnclub2man.TabIndex = 46;
            this.btnclub2man.Text = "MANAGER";
            this.btnclub2man.UseVisualStyleBackColor = true;
            this.btnclub2man.Click += new System.EventHandler(this.btnclub2man_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(546, 32);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 45;
            this.button8.Text = "CLUB";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // txtsearchclub
            // 
            this.txtsearchclub.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchclub.Location = new System.Drawing.Point(274, 136);
            this.txtsearchclub.Name = "txtsearchclub";
            this.txtsearchclub.Size = new System.Drawing.Size(368, 23);
            this.txtsearchclub.TabIndex = 43;
            // 
            // btnfilterclub
            // 
            this.btnfilterclub.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfilterclub.Location = new System.Drawing.Point(891, 126);
            this.btnfilterclub.Name = "btnfilterclub";
            this.btnfilterclub.Size = new System.Drawing.Size(131, 76);
            this.btnfilterclub.TabIndex = 42;
            this.btnfilterclub.Text = "FILTER";
            this.btnfilterclub.UseVisualStyleBackColor = true;
            this.btnfilterclub.Click += new System.EventHandler(this.btnfilterclub_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(360, 55);
            this.label8.MinimumSize = new System.Drawing.Size(5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 16);
            this.label8.TabIndex = 41;
            this.label8.Text = "SEARCH FOR:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(38, 79);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(191, 107);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 40;
            this.pictureBox3.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1, 33);
            this.label9.MinimumSize = new System.Drawing.Size(5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(367, 25);
            this.label9.TabIndex = 39;
            this.label9.Text = "PREMIER LEAGUE CLUB DATABASE";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Gold;
            this.tabPage7.Controls.Add(this.lblmanmode);
            this.tabPage7.Controls.Add(this.label19);
            this.tabPage7.Controls.Add(this.label18);
            this.tabPage7.Controls.Add(this.btnman2player);
            this.tabPage7.Controls.Add(this.gridman);
            this.tabPage7.Controls.Add(this.label11);
            this.tabPage7.Controls.Add(this.btnmandelete);
            this.tabPage7.Controls.Add(this.btnmanupdate);
            this.tabPage7.Controls.Add(this.btnmanadd);
            this.tabPage7.Controls.Add(this.label12);
            this.tabPage7.Controls.Add(this.comboBox1);
            this.tabPage7.Controls.Add(this.ma);
            this.tabPage7.Controls.Add(this.comboBox3);
            this.tabPage7.Controls.Add(this.btnman2nat);
            this.tabPage7.Controls.Add(this.btnman2comp);
            this.tabPage7.Controls.Add(this.button12);
            this.tabPage7.Controls.Add(this.button13);
            this.tabPage7.Controls.Add(this.btnman2club);
            this.tabPage7.Controls.Add(this.txtsearchman);
            this.tabPage7.Controls.Add(this.btnmanfilter);
            this.tabPage7.Controls.Add(this.label15);
            this.tabPage7.Controls.Add(this.pictureBox4);
            this.tabPage7.Controls.Add(this.label16);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1140, 561);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "MANAGER";
            // 
            // lblmanmode
            // 
            this.lblmanmode.AutoSize = true;
            this.lblmanmode.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmanmode.Location = new System.Drawing.Point(883, 66);
            this.lblmanmode.Name = "lblmanmode";
            this.lblmanmode.Size = new System.Drawing.Size(19, 21);
            this.lblmanmode.TabIndex = 89;
            this.lblmanmode.Text = "L";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(247, 172);
            this.label19.MinimumSize = new System.Drawing.Size(5, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(145, 16);
            this.label19.TabIndex = 88;
            this.label19.Text = "FILTER BY LAST NAME";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(419, 173);
            this.label18.MinimumSize = new System.Drawing.Size(5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 16);
            this.label18.TabIndex = 87;
            this.label18.Text = "FILTER BY AGE:";
            // 
            // btnman2player
            // 
            this.btnman2player.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnman2player.Location = new System.Drawing.Point(448, 35);
            this.btnman2player.Name = "btnman2player";
            this.btnman2player.Size = new System.Drawing.Size(75, 23);
            this.btnman2player.TabIndex = 85;
            this.btnman2player.Text = "PLAYER";
            this.btnman2player.UseVisualStyleBackColor = true;
            this.btnman2player.Click += new System.EventHandler(this.btnman2player_Click);
            // 
            // gridman
            // 
            this.gridman.AutoGenerateColumns = false;
            this.gridman.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridman.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.manIDDataGridViewTextBoxColumn,
            this.manLnameDataGridViewTextBoxColumn,
            this.manFnameDataGridViewTextBoxColumn,
            this.manNatDataGridViewTextBoxColumn,
            this.manDOBDataGridViewTextBoxColumn});
            this.gridman.DataSource = this.managerBindingSource;
            this.gridman.Location = new System.Drawing.Point(214, 233);
            this.gridman.Name = "gridman";
            this.gridman.Size = new System.Drawing.Size(576, 240);
            this.gridman.TabIndex = 84;
            // 
            // manIDDataGridViewTextBoxColumn
            // 
            this.manIDDataGridViewTextBoxColumn.DataPropertyName = "Man_ID";
            this.manIDDataGridViewTextBoxColumn.HeaderText = "Man_ID";
            this.manIDDataGridViewTextBoxColumn.Name = "manIDDataGridViewTextBoxColumn";
            // 
            // manLnameDataGridViewTextBoxColumn
            // 
            this.manLnameDataGridViewTextBoxColumn.DataPropertyName = "Man_Lname";
            this.manLnameDataGridViewTextBoxColumn.HeaderText = "Man_Lname";
            this.manLnameDataGridViewTextBoxColumn.Name = "manLnameDataGridViewTextBoxColumn";
            // 
            // manFnameDataGridViewTextBoxColumn
            // 
            this.manFnameDataGridViewTextBoxColumn.DataPropertyName = "Man_Fname";
            this.manFnameDataGridViewTextBoxColumn.HeaderText = "Man_Fname";
            this.manFnameDataGridViewTextBoxColumn.Name = "manFnameDataGridViewTextBoxColumn";
            // 
            // manNatDataGridViewTextBoxColumn
            // 
            this.manNatDataGridViewTextBoxColumn.DataPropertyName = "Man_Nat";
            this.manNatDataGridViewTextBoxColumn.HeaderText = "Man_Nat";
            this.manNatDataGridViewTextBoxColumn.Name = "manNatDataGridViewTextBoxColumn";
            // 
            // manDOBDataGridViewTextBoxColumn
            // 
            this.manDOBDataGridViewTextBoxColumn.DataPropertyName = "Man_DOB";
            this.manDOBDataGridViewTextBoxColumn.HeaderText = "Man_DOB";
            this.manDOBDataGridViewTextBoxColumn.Name = "manDOBDataGridViewTextBoxColumn";
            // 
            // managerBindingSource
            // 
            this.managerBindingSource.DataMember = "manager";
            this.managerBindingSource.DataSource = this.pldataDataSet;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(529, 173);
            this.label11.MinimumSize = new System.Drawing.Size(5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(163, 16);
            this.label11.TabIndex = 83;
            this.label11.Text = "FILTER BY NATIONALITY:";
            // 
            // btnmandelete
            // 
            this.btnmandelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmandelete.Location = new System.Drawing.Point(733, 166);
            this.btnmandelete.Name = "btnmandelete";
            this.btnmandelete.Size = new System.Drawing.Size(75, 23);
            this.btnmandelete.TabIndex = 82;
            this.btnmandelete.Text = "DELETE";
            this.btnmandelete.UseVisualStyleBackColor = true;
            this.btnmandelete.Click += new System.EventHandler(this.btnmandelete_Click);
            // 
            // btnmanupdate
            // 
            this.btnmanupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanupdate.Location = new System.Drawing.Point(733, 137);
            this.btnmanupdate.Name = "btnmanupdate";
            this.btnmanupdate.Size = new System.Drawing.Size(75, 23);
            this.btnmanupdate.TabIndex = 81;
            this.btnmanupdate.Text = "UPDATE";
            this.btnmanupdate.UseVisualStyleBackColor = true;
            this.btnmanupdate.Click += new System.EventHandler(this.btnmanupdate_Click);
            // 
            // btnmanadd
            // 
            this.btnmanadd.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanadd.Location = new System.Drawing.Point(733, 107);
            this.btnmanadd.Name = "btnmanadd";
            this.btnmanadd.Size = new System.Drawing.Size(75, 23);
            this.btnmanadd.TabIndex = 80;
            this.btnmanadd.Text = "ADD";
            this.btnmanadd.UseVisualStyleBackColor = true;
            this.btnmanadd.Click += new System.EventHandler(this.btnmanadd_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(432, 110);
            this.label12.MinimumSize = new System.Drawing.Size(5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 16);
            this.label12.TabIndex = 79;
            this.label12.Text = "SEARCH CRITERIA:";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Alphabetical: A-Z",
            "Alphabetical: Z-A"});
            this.comboBox1.Location = new System.Drawing.Point(550, 189);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 78;
            // 
            // ma
            // 
            this.ma.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ma.FormattingEnabled = true;
            this.ma.Items.AddRange(new object[] {
            "Alphabetical: A-Z",
            "Alphabetical: Z-A"});
            this.ma.Location = new System.Drawing.Point(259, 189);
            this.ma.Name = "ma";
            this.ma.Size = new System.Drawing.Size(121, 24);
            this.ma.TabIndex = 75;
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Youngest to Oldest",
            "Oldest to Youngest"});
            this.comboBox3.Location = new System.Drawing.Point(402, 189);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 24);
            this.comboBox3.TabIndex = 74;
            // 
            // btnman2nat
            // 
            this.btnman2nat.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnman2nat.Location = new System.Drawing.Point(640, 75);
            this.btnman2nat.Name = "btnman2nat";
            this.btnman2nat.Size = new System.Drawing.Size(125, 23);
            this.btnman2nat.TabIndex = 73;
            this.btnman2nat.Text = "NATIONAL TEAM";
            this.btnman2nat.UseVisualStyleBackColor = true;
            this.btnman2nat.Click += new System.EventHandler(this.btnman2nat_Click);
            // 
            // btnman2comp
            // 
            this.btnman2comp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnman2comp.Location = new System.Drawing.Point(640, 36);
            this.btnman2comp.Name = "btnman2comp";
            this.btnman2comp.Size = new System.Drawing.Size(125, 23);
            this.btnman2comp.TabIndex = 72;
            this.btnman2comp.Text = "COMPETITION";
            this.btnman2comp.UseVisualStyleBackColor = true;
            this.btnman2comp.Click += new System.EventHandler(this.btnman2comp_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(549, 74);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 71;
            this.button12.Text = "HISTORY";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(448, 74);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(85, 23);
            this.button13.TabIndex = 70;
            this.button13.Text = "MANAGER";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // btnman2club
            // 
            this.btnman2club.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnman2club.Location = new System.Drawing.Point(549, 35);
            this.btnman2club.Name = "btnman2club";
            this.btnman2club.Size = new System.Drawing.Size(75, 23);
            this.btnman2club.TabIndex = 69;
            this.btnman2club.Text = "CLUB";
            this.btnman2club.UseVisualStyleBackColor = true;
            this.btnman2club.Click += new System.EventHandler(this.btnman2club_Click);
            // 
            // txtsearchman
            // 
            this.txtsearchman.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchman.Location = new System.Drawing.Point(303, 138);
            this.txtsearchman.Name = "txtsearchman";
            this.txtsearchman.Size = new System.Drawing.Size(368, 23);
            this.txtsearchman.TabIndex = 68;
            // 
            // btnmanfilter
            // 
            this.btnmanfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanfilter.Location = new System.Drawing.Point(897, 129);
            this.btnmanfilter.Name = "btnmanfilter";
            this.btnmanfilter.Size = new System.Drawing.Size(131, 76);
            this.btnmanfilter.TabIndex = 67;
            this.btnmanfilter.Text = "FILTER";
            this.btnmanfilter.UseVisualStyleBackColor = true;
            this.btnmanfilter.Click += new System.EventHandler(this.btnmanfilter_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(359, 62);
            this.label15.MinimumSize = new System.Drawing.Size(5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 16);
            this.label15.TabIndex = 66;
            this.label15.Text = "SEARCH FOR:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(76, 50);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(191, 107);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 65;
            this.pictureBox4.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 19);
            this.label16.MinimumSize = new System.Drawing.Size(5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(415, 25);
            this.label16.TabIndex = 64;
            this.label16.Text = "PREMIER LEAGUE MANAGER DATABASE";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.IndianRed;
            this.tabPage8.Controls.Add(this.lblnatmode);
            this.tabPage8.Controls.Add(this.btnnat2player);
            this.tabPage8.Controls.Add(this.gridnat);
            this.tabPage8.Controls.Add(this.label20);
            this.tabPage8.Controls.Add(this.btnnatdelete);
            this.tabPage8.Controls.Add(this.btnnatupdate);
            this.tabPage8.Controls.Add(this.btnnatadd);
            this.tabPage8.Controls.Add(this.label21);
            this.tabPage8.Controls.Add(this.natteamcap);
            this.tabPage8.Controls.Add(this.label22);
            this.tabPage8.Controls.Add(this.label23);
            this.tabPage8.Controls.Add(this.natfiltername);
            this.tabPage8.Controls.Add(this.natteamcity);
            this.tabPage8.Controls.Add(this.button9);
            this.tabPage8.Controls.Add(this.btnnat2comp);
            this.tabPage8.Controls.Add(this.btnnat2hist);
            this.tabPage8.Controls.Add(this.btnnat2man);
            this.tabPage8.Controls.Add(this.btnnat2club);
            this.tabPage8.Controls.Add(this.txtsearchnat);
            this.tabPage8.Controls.Add(this.btnnatfilter);
            this.tabPage8.Controls.Add(this.label24);
            this.tabPage8.Controls.Add(this.pictureBox5);
            this.tabPage8.Controls.Add(this.label25);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1140, 561);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "NAT TEAM";
            // 
            // lblnatmode
            // 
            this.lblnatmode.AutoSize = true;
            this.lblnatmode.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnatmode.Location = new System.Drawing.Point(873, 59);
            this.lblnatmode.Name = "lblnatmode";
            this.lblnatmode.Size = new System.Drawing.Size(19, 21);
            this.lblnatmode.TabIndex = 90;
            this.lblnatmode.Text = "L";
            // 
            // btnnat2player
            // 
            this.btnnat2player.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnat2player.Location = new System.Drawing.Point(384, 71);
            this.btnnat2player.Name = "btnnat2player";
            this.btnnat2player.Size = new System.Drawing.Size(75, 23);
            this.btnnat2player.TabIndex = 85;
            this.btnnat2player.Text = "PLAYER";
            this.btnnat2player.UseVisualStyleBackColor = true;
            this.btnnat2player.Click += new System.EventHandler(this.btnnat2player_Click);
            // 
            // gridnat
            // 
            this.gridnat.AutoGenerateColumns = false;
            this.gridnat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridnat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.natTeamCountryDataGridViewTextBoxColumn1,
            this.natTeamStadiumDataGridViewTextBoxColumn,
            this.natTeamCityDataGridViewTextBoxColumn,
            this.natTeamCapacityDataGridViewTextBoxColumn});
            this.gridnat.DataSource = this.nationalteamBindingSource;
            this.gridnat.Location = new System.Drawing.Point(292, 243);
            this.gridnat.Name = "gridnat";
            this.gridnat.Size = new System.Drawing.Size(516, 240);
            this.gridnat.TabIndex = 84;
            // 
            // natTeamCountryDataGridViewTextBoxColumn1
            // 
            this.natTeamCountryDataGridViewTextBoxColumn1.DataPropertyName = "Nat_Team_Country";
            this.natTeamCountryDataGridViewTextBoxColumn1.HeaderText = "Nat_Team_Country";
            this.natTeamCountryDataGridViewTextBoxColumn1.Name = "natTeamCountryDataGridViewTextBoxColumn1";
            // 
            // natTeamStadiumDataGridViewTextBoxColumn
            // 
            this.natTeamStadiumDataGridViewTextBoxColumn.DataPropertyName = "Nat_Team_Stadium";
            this.natTeamStadiumDataGridViewTextBoxColumn.HeaderText = "Nat_Team_Stadium";
            this.natTeamStadiumDataGridViewTextBoxColumn.Name = "natTeamStadiumDataGridViewTextBoxColumn";
            // 
            // natTeamCityDataGridViewTextBoxColumn
            // 
            this.natTeamCityDataGridViewTextBoxColumn.DataPropertyName = "Nat_Team_City";
            this.natTeamCityDataGridViewTextBoxColumn.HeaderText = "Nat_Team_City";
            this.natTeamCityDataGridViewTextBoxColumn.Name = "natTeamCityDataGridViewTextBoxColumn";
            // 
            // natTeamCapacityDataGridViewTextBoxColumn
            // 
            this.natTeamCapacityDataGridViewTextBoxColumn.DataPropertyName = "Nat_Team_Capacity";
            this.natTeamCapacityDataGridViewTextBoxColumn.HeaderText = "Nat_Team_Capacity";
            this.natTeamCapacityDataGridViewTextBoxColumn.Name = "natTeamCapacityDataGridViewTextBoxColumn";
            // 
            // nationalteamBindingSource
            // 
            this.nationalteamBindingSource.DataMember = "national_team";
            this.nationalteamBindingSource.DataSource = this.pldataDataSet;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(573, 192);
            this.label20.MinimumSize = new System.Drawing.Size(5, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(201, 16);
            this.label20.TabIndex = 83;
            this.label20.Text = "FILTER BY STADIUM CAPACITY:";
            // 
            // btnnatdelete
            // 
            this.btnnatdelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnatdelete.Location = new System.Drawing.Point(752, 158);
            this.btnnatdelete.Name = "btnnatdelete";
            this.btnnatdelete.Size = new System.Drawing.Size(75, 23);
            this.btnnatdelete.TabIndex = 82;
            this.btnnatdelete.Text = "DELETE";
            this.btnnatdelete.UseVisualStyleBackColor = true;
            this.btnnatdelete.Click += new System.EventHandler(this.btnnatdelete_Click);
            // 
            // btnnatupdate
            // 
            this.btnnatupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnatupdate.Location = new System.Drawing.Point(752, 129);
            this.btnnatupdate.Name = "btnnatupdate";
            this.btnnatupdate.Size = new System.Drawing.Size(75, 23);
            this.btnnatupdate.TabIndex = 81;
            this.btnnatupdate.Text = "UPDATE";
            this.btnnatupdate.UseVisualStyleBackColor = true;
            this.btnnatupdate.Click += new System.EventHandler(this.btnnatupdate_Click);
            // 
            // btnnatadd
            // 
            this.btnnatadd.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnatadd.Location = new System.Drawing.Point(752, 99);
            this.btnnatadd.Name = "btnnatadd";
            this.btnnatadd.Size = new System.Drawing.Size(75, 23);
            this.btnnatadd.TabIndex = 80;
            this.btnnatadd.Text = "ADD";
            this.btnnatadd.UseVisualStyleBackColor = true;
            this.btnnatadd.Click += new System.EventHandler(this.btnnatadd_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(473, 142);
            this.label21.MinimumSize = new System.Drawing.Size(5, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(126, 16);
            this.label21.TabIndex = 79;
            this.label21.Text = "SEARCH CRITERIA:";
            // 
            // natteamcap
            // 
            this.natteamcap.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.natteamcap.FormattingEnabled = true;
            this.natteamcap.Items.AddRange(new object[] {
            "Lowest to Highest",
            "HIghest to Lowest"});
            this.natteamcap.Location = new System.Drawing.Point(587, 208);
            this.natteamcap.Name = "natteamcap";
            this.natteamcap.Size = new System.Drawing.Size(121, 24);
            this.natteamcap.TabIndex = 78;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(299, 192);
            this.label22.MinimumSize = new System.Drawing.Size(5, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(114, 16);
            this.label22.TabIndex = 77;
            this.label22.Text = "FILTER BY NAME:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(446, 192);
            this.label23.MinimumSize = new System.Drawing.Size(5, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 16);
            this.label23.TabIndex = 76;
            this.label23.Text = "FILTER BY CITY:";
            // 
            // natfiltername
            // 
            this.natfiltername.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.natfiltername.FormattingEnabled = true;
            this.natfiltername.Items.AddRange(new object[] {
            "National Team Name: A-Z",
            "National Team Name: Z-A"});
            this.natfiltername.Location = new System.Drawing.Point(296, 208);
            this.natfiltername.Name = "natfiltername";
            this.natfiltername.Size = new System.Drawing.Size(121, 24);
            this.natfiltername.TabIndex = 75;
            // 
            // natteamcity
            // 
            this.natteamcity.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.natteamcity.FormattingEnabled = true;
            this.natteamcity.Items.AddRange(new object[] {
            "City Name: A-Z",
            "City Name: Z-A"});
            this.natteamcity.Location = new System.Drawing.Point(439, 208);
            this.natteamcity.Name = "natteamcity";
            this.natteamcity.Size = new System.Drawing.Size(121, 24);
            this.natteamcity.TabIndex = 74;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(576, 111);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(125, 23);
            this.button9.TabIndex = 73;
            this.button9.Text = "NATIONAL TEAM";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // btnnat2comp
            // 
            this.btnnat2comp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnat2comp.Location = new System.Drawing.Point(576, 72);
            this.btnnat2comp.Name = "btnnat2comp";
            this.btnnat2comp.Size = new System.Drawing.Size(125, 23);
            this.btnnat2comp.TabIndex = 72;
            this.btnnat2comp.Text = "COMPETITION";
            this.btnnat2comp.UseVisualStyleBackColor = true;
            this.btnnat2comp.Click += new System.EventHandler(this.btnnat2comp_Click);
            // 
            // btnnat2hist
            // 
            this.btnnat2hist.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnat2hist.Location = new System.Drawing.Point(485, 110);
            this.btnnat2hist.Name = "btnnat2hist";
            this.btnnat2hist.Size = new System.Drawing.Size(75, 23);
            this.btnnat2hist.TabIndex = 71;
            this.btnnat2hist.Text = "HISTORY";
            this.btnnat2hist.UseVisualStyleBackColor = true;
            this.btnnat2hist.Click += new System.EventHandler(this.btnnat2hist_Click);
            // 
            // btnnat2man
            // 
            this.btnnat2man.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnat2man.Location = new System.Drawing.Point(384, 110);
            this.btnnat2man.Name = "btnnat2man";
            this.btnnat2man.Size = new System.Drawing.Size(95, 23);
            this.btnnat2man.TabIndex = 70;
            this.btnnat2man.Text = "MANAGER";
            this.btnnat2man.UseVisualStyleBackColor = true;
            this.btnnat2man.Click += new System.EventHandler(this.btnnat2man_Click);
            // 
            // btnnat2club
            // 
            this.btnnat2club.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnat2club.Location = new System.Drawing.Point(485, 71);
            this.btnnat2club.Name = "btnnat2club";
            this.btnnat2club.Size = new System.Drawing.Size(75, 23);
            this.btnnat2club.TabIndex = 69;
            this.btnnat2club.Text = "CLUB";
            this.btnnat2club.UseVisualStyleBackColor = true;
            this.btnnat2club.Click += new System.EventHandler(this.btnnat2club_Click);
            // 
            // txtsearchnat
            // 
            this.txtsearchnat.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchnat.Location = new System.Drawing.Point(340, 158);
            this.txtsearchnat.Name = "txtsearchnat";
            this.txtsearchnat.Size = new System.Drawing.Size(368, 23);
            this.txtsearchnat.TabIndex = 68;
            // 
            // btnnatfilter
            // 
            this.btnnatfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnatfilter.Location = new System.Drawing.Point(897, 129);
            this.btnnatfilter.Name = "btnnatfilter";
            this.btnnatfilter.Size = new System.Drawing.Size(131, 76);
            this.btnnatfilter.TabIndex = 67;
            this.btnnatfilter.Text = "FILTER";
            this.btnnatfilter.UseVisualStyleBackColor = true;
            this.btnnatfilter.Click += new System.EventHandler(this.btnnatfilter_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(299, 91);
            this.label24.MinimumSize = new System.Drawing.Size(5, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(92, 16);
            this.label24.TabIndex = 66;
            this.label24.Text = "SEARCH FOR:";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(71, 71);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(191, 107);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 65;
            this.pictureBox5.TabStop = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(3, 29);
            this.label25.MinimumSize = new System.Drawing.Size(5, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(483, 25);
            this.label25.TabIndex = 64;
            this.label25.Text = "PREMIER LEAGUE NATIONAL TEAM DATABASE";
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.GreenYellow;
            this.tabPage9.Controls.Add(this.lblhismode);
            this.tabPage9.Controls.Add(this.btnhis2player);
            this.tabPage9.Controls.Add(this.gridhis);
            this.tabPage9.Controls.Add(this.label26);
            this.tabPage9.Controls.Add(this.btnhisdelete);
            this.tabPage9.Controls.Add(this.btnhisupdate);
            this.tabPage9.Controls.Add(this.btnhisadd);
            this.tabPage9.Controls.Add(this.label27);
            this.tabPage9.Controls.Add(this.hisfilterdate);
            this.tabPage9.Controls.Add(this.label28);
            this.tabPage9.Controls.Add(this.label29);
            this.tabPage9.Controls.Add(this.hisfiltername);
            this.tabPage9.Controls.Add(this.hisfilterclub);
            this.tabPage9.Controls.Add(this.btnhisttonat);
            this.tabPage9.Controls.Add(this.btnhist2comp);
            this.tabPage9.Controls.Add(this.button18);
            this.tabPage9.Controls.Add(this.btnhis2man);
            this.tabPage9.Controls.Add(this.btnhis2club);
            this.tabPage9.Controls.Add(this.txtsearchhis);
            this.tabPage9.Controls.Add(this.btnhisfilter);
            this.tabPage9.Controls.Add(this.label30);
            this.tabPage9.Controls.Add(this.pictureBox6);
            this.tabPage9.Controls.Add(this.label31);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(1140, 561);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "HISTORY";
            // 
            // lblhismode
            // 
            this.lblhismode.AutoSize = true;
            this.lblhismode.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhismode.Location = new System.Drawing.Point(874, 65);
            this.lblhismode.Name = "lblhismode";
            this.lblhismode.Size = new System.Drawing.Size(19, 21);
            this.lblhismode.TabIndex = 108;
            this.lblhismode.Text = "L";
            // 
            // btnhis2player
            // 
            this.btnhis2player.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhis2player.Location = new System.Drawing.Point(388, 66);
            this.btnhis2player.Name = "btnhis2player";
            this.btnhis2player.Size = new System.Drawing.Size(75, 23);
            this.btnhis2player.TabIndex = 107;
            this.btnhis2player.Text = "PLAYER";
            this.btnhis2player.UseVisualStyleBackColor = true;
            this.btnhis2player.Click += new System.EventHandler(this.btnhis2player_Click);
            // 
            // gridhis
            // 
            this.gridhis.AutoGenerateColumns = false;
            this.gridhis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridhis.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pLAYERLNAMEDataGridViewTextBoxColumn1,
            this.pLAYERFNAMEDataGridViewTextBoxColumn1,
            this.cLUBNAMEDataGridViewTextBoxColumn1,
            this.tEAMSTARTDATEDataGridViewTextBoxColumn});
            this.gridhis.DataSource = this.playerrecordview1BindingSource;
            this.gridhis.Location = new System.Drawing.Point(234, 259);
            this.gridhis.Name = "gridhis";
            this.gridhis.Size = new System.Drawing.Size(513, 226);
            this.gridhis.TabIndex = 106;
            // 
            // pLAYERLNAMEDataGridViewTextBoxColumn1
            // 
            this.pLAYERLNAMEDataGridViewTextBoxColumn1.DataPropertyName = "PLAYER_LNAME";
            this.pLAYERLNAMEDataGridViewTextBoxColumn1.HeaderText = "PLAYER_LNAME";
            this.pLAYERLNAMEDataGridViewTextBoxColumn1.Name = "pLAYERLNAMEDataGridViewTextBoxColumn1";
            // 
            // pLAYERFNAMEDataGridViewTextBoxColumn1
            // 
            this.pLAYERFNAMEDataGridViewTextBoxColumn1.DataPropertyName = "PLAYER_FNAME";
            this.pLAYERFNAMEDataGridViewTextBoxColumn1.HeaderText = "PLAYER_FNAME";
            this.pLAYERFNAMEDataGridViewTextBoxColumn1.Name = "pLAYERFNAMEDataGridViewTextBoxColumn1";
            // 
            // cLUBNAMEDataGridViewTextBoxColumn1
            // 
            this.cLUBNAMEDataGridViewTextBoxColumn1.DataPropertyName = "CLUB_NAME";
            this.cLUBNAMEDataGridViewTextBoxColumn1.HeaderText = "CLUB_NAME";
            this.cLUBNAMEDataGridViewTextBoxColumn1.Name = "cLUBNAMEDataGridViewTextBoxColumn1";
            // 
            // tEAMSTARTDATEDataGridViewTextBoxColumn
            // 
            this.tEAMSTARTDATEDataGridViewTextBoxColumn.DataPropertyName = "TEAM_START_DATE";
            this.tEAMSTARTDATEDataGridViewTextBoxColumn.HeaderText = "START_DATE";
            this.tEAMSTARTDATEDataGridViewTextBoxColumn.Name = "tEAMSTARTDATEDataGridViewTextBoxColumn";
            // 
            // playerrecordview1BindingSource
            // 
            this.playerrecordview1BindingSource.DataMember = "player_record_view1";
            this.playerrecordview1BindingSource.DataSource = this.pldataDataSet21;
            // 
            // pldataDataSet21
            // 
            this.pldataDataSet21.DataSetName = "pldataDataSet2";
            this.pldataDataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(592, 199);
            this.label26.MinimumSize = new System.Drawing.Size(5, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(155, 16);
            this.label26.TabIndex = 105;
            this.label26.Text = "FILTER BY START DATE:";
            // 
            // btnhisdelete
            // 
            this.btnhisdelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhisdelete.Location = new System.Drawing.Point(733, 173);
            this.btnhisdelete.Name = "btnhisdelete";
            this.btnhisdelete.Size = new System.Drawing.Size(75, 23);
            this.btnhisdelete.TabIndex = 104;
            this.btnhisdelete.Text = "DELETE";
            this.btnhisdelete.UseVisualStyleBackColor = true;
            this.btnhisdelete.Click += new System.EventHandler(this.btnhisdelete_Click);
            // 
            // btnhisupdate
            // 
            this.btnhisupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhisupdate.Location = new System.Drawing.Point(733, 144);
            this.btnhisupdate.Name = "btnhisupdate";
            this.btnhisupdate.Size = new System.Drawing.Size(75, 23);
            this.btnhisupdate.TabIndex = 103;
            this.btnhisupdate.Text = "UPDATE";
            this.btnhisupdate.UseVisualStyleBackColor = true;
            this.btnhisupdate.Click += new System.EventHandler(this.btnhisupdate_Click);
            // 
            // btnhisadd
            // 
            this.btnhisadd.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhisadd.Location = new System.Drawing.Point(733, 114);
            this.btnhisadd.Name = "btnhisadd";
            this.btnhisadd.Size = new System.Drawing.Size(75, 23);
            this.btnhisadd.TabIndex = 102;
            this.btnhisadd.Text = "ADD";
            this.btnhisadd.UseVisualStyleBackColor = true;
            this.btnhisadd.Click += new System.EventHandler(this.btnhisadd_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(473, 144);
            this.label27.MinimumSize = new System.Drawing.Size(5, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(126, 16);
            this.label27.TabIndex = 101;
            this.label27.Text = "SEARCH CRITERIA:";
            // 
            // hisfilterdate
            // 
            this.hisfilterdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hisfilterdate.FormattingEnabled = true;
            this.hisfilterdate.Items.AddRange(new object[] {
            "Earliest to Most Recent",
            "Most Recent to Earliest"});
            this.hisfilterdate.Location = new System.Drawing.Point(595, 215);
            this.hisfilterdate.Name = "hisfilterdate";
            this.hisfilterdate.Size = new System.Drawing.Size(121, 24);
            this.hisfilterdate.TabIndex = 100;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(231, 199);
            this.label28.MinimumSize = new System.Drawing.Size(5, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(199, 16);
            this.label28.TabIndex = 99;
            this.label28.Text = "FILTER BY PLAYER LAST NAME:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(435, 199);
            this.label29.MinimumSize = new System.Drawing.Size(5, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(151, 16);
            this.label29.TabIndex = 98;
            this.label29.Text = "FILTER BY CLUB NAME:";
            // 
            // hisfiltername
            // 
            this.hisfiltername.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hisfiltername.FormattingEnabled = true;
            this.hisfiltername.Items.AddRange(new object[] {
            "Alphabetical: A-Z",
            "Alphabetical: Z-A"});
            this.hisfiltername.Location = new System.Drawing.Point(284, 215);
            this.hisfiltername.Name = "hisfiltername";
            this.hisfiltername.Size = new System.Drawing.Size(121, 24);
            this.hisfiltername.TabIndex = 97;
            // 
            // hisfilterclub
            // 
            this.hisfilterclub.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hisfilterclub.FormattingEnabled = true;
            this.hisfilterclub.Items.AddRange(new object[] {
            "Club Name: A-Z",
            "Club Name: Z-A"});
            this.hisfilterclub.Location = new System.Drawing.Point(436, 215);
            this.hisfilterclub.Name = "hisfilterclub";
            this.hisfilterclub.Size = new System.Drawing.Size(121, 24);
            this.hisfilterclub.TabIndex = 96;
            // 
            // btnhisttonat
            // 
            this.btnhisttonat.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhisttonat.Location = new System.Drawing.Point(580, 106);
            this.btnhisttonat.Name = "btnhisttonat";
            this.btnhisttonat.Size = new System.Drawing.Size(125, 23);
            this.btnhisttonat.TabIndex = 95;
            this.btnhisttonat.Text = "NATIONAL TEAM";
            this.btnhisttonat.UseVisualStyleBackColor = true;
            this.btnhisttonat.Click += new System.EventHandler(this.btnhisttonat_Click);
            // 
            // btnhist2comp
            // 
            this.btnhist2comp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhist2comp.Location = new System.Drawing.Point(580, 67);
            this.btnhist2comp.Name = "btnhist2comp";
            this.btnhist2comp.Size = new System.Drawing.Size(125, 23);
            this.btnhist2comp.TabIndex = 94;
            this.btnhist2comp.Text = "COMPETITION";
            this.btnhist2comp.UseVisualStyleBackColor = true;
            this.btnhist2comp.Click += new System.EventHandler(this.btnhist2comp_Click);
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(489, 105);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 93;
            this.button18.Text = "HISTORY";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // btnhis2man
            // 
            this.btnhis2man.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhis2man.Location = new System.Drawing.Point(388, 105);
            this.btnhis2man.Name = "btnhis2man";
            this.btnhis2man.Size = new System.Drawing.Size(85, 23);
            this.btnhis2man.TabIndex = 92;
            this.btnhis2man.Text = "MANAGER";
            this.btnhis2man.UseVisualStyleBackColor = true;
            this.btnhis2man.Click += new System.EventHandler(this.btnhis2man_Click);
            // 
            // btnhis2club
            // 
            this.btnhis2club.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhis2club.Location = new System.Drawing.Point(489, 66);
            this.btnhis2club.Name = "btnhis2club";
            this.btnhis2club.Size = new System.Drawing.Size(75, 23);
            this.btnhis2club.TabIndex = 91;
            this.btnhis2club.Text = "CLUB";
            this.btnhis2club.UseVisualStyleBackColor = true;
            this.btnhis2club.Click += new System.EventHandler(this.btnhis2club_Click);
            // 
            // txtsearchhis
            // 
            this.txtsearchhis.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchhis.Location = new System.Drawing.Point(324, 165);
            this.txtsearchhis.Name = "txtsearchhis";
            this.txtsearchhis.Size = new System.Drawing.Size(368, 23);
            this.txtsearchhis.TabIndex = 90;
            // 
            // btnhisfilter
            // 
            this.btnhisfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhisfilter.Location = new System.Drawing.Point(897, 136);
            this.btnhisfilter.Name = "btnhisfilter";
            this.btnhisfilter.Size = new System.Drawing.Size(131, 76);
            this.btnhisfilter.TabIndex = 89;
            this.btnhisfilter.Text = "FILTER";
            this.btnhisfilter.UseVisualStyleBackColor = true;
            this.btnhisfilter.Click += new System.EventHandler(this.btnhisfilter_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(303, 86);
            this.label30.MinimumSize = new System.Drawing.Size(5, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(92, 16);
            this.label30.TabIndex = 88;
            this.label30.Text = "SEARCH FOR:";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(64, 67);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(191, 107);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 87;
            this.pictureBox6.TabStop = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(3, 28);
            this.label31.MinimumSize = new System.Drawing.Size(5, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(486, 25);
            this.label31.TabIndex = 86;
            this.label31.Text = "PREMIER LEAGUE PLAYER HISTORY DATABASE";
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Fuchsia;
            this.tabPage10.Controls.Add(this.lblcompmode);
            this.tabPage10.Controls.Add(this.label37);
            this.tabPage10.Controls.Add(this.btncomp2play);
            this.tabPage10.Controls.Add(this.gridcomp);
            this.tabPage10.Controls.Add(this.label32);
            this.tabPage10.Controls.Add(this.btncompdelete);
            this.tabPage10.Controls.Add(this.btncompupdate);
            this.tabPage10.Controls.Add(this.btncompadd);
            this.tabPage10.Controls.Add(this.compfiltstat);
            this.tabPage10.Controls.Add(this.label33);
            this.tabPage10.Controls.Add(this.label34);
            this.tabPage10.Controls.Add(this.compfiltcomp);
            this.tabPage10.Controls.Add(this.compfilterclub);
            this.tabPage10.Controls.Add(this.btncomp2nat);
            this.tabPage10.Controls.Add(this.button20);
            this.tabPage10.Controls.Add(this.btncomp2his);
            this.tabPage10.Controls.Add(this.btncomp2man);
            this.tabPage10.Controls.Add(this.btncomp2club);
            this.tabPage10.Controls.Add(this.txtsearchcomp);
            this.tabPage10.Controls.Add(this.btncompfilter);
            this.tabPage10.Controls.Add(this.label35);
            this.tabPage10.Controls.Add(this.pictureBox7);
            this.tabPage10.Controls.Add(this.label36);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1140, 561);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "COMPETITION";
            // 
            // lblcompmode
            // 
            this.lblcompmode.AutoSize = true;
            this.lblcompmode.Font = new System.Drawing.Font("Goudy Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcompmode.Location = new System.Drawing.Point(903, 61);
            this.lblcompmode.Name = "lblcompmode";
            this.lblcompmode.Size = new System.Drawing.Size(19, 21);
            this.lblcompmode.TabIndex = 130;
            this.lblcompmode.Text = "L";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(463, 142);
            this.label37.MinimumSize = new System.Drawing.Size(5, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(126, 16);
            this.label37.TabIndex = 129;
            this.label37.Text = "SEARCH CRITERIA:";
            // 
            // btncomp2play
            // 
            this.btncomp2play.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomp2play.Location = new System.Drawing.Point(380, 58);
            this.btncomp2play.Name = "btncomp2play";
            this.btncomp2play.Size = new System.Drawing.Size(75, 23);
            this.btncomp2play.TabIndex = 128;
            this.btncomp2play.Text = "PLAYER";
            this.btncomp2play.UseVisualStyleBackColor = true;
            this.btncomp2play.Click += new System.EventHandler(this.btncomp2play_Click);
            // 
            // gridcomp
            // 
            this.gridcomp.AutoGenerateColumns = false;
            this.gridcomp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridcomp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cLUBIDDataGridViewTextBoxColumn1,
            this.cLUBNAMEDataGridViewTextBoxColumn2,
            this.cOMPNAMEDataGridViewTextBoxColumn,
            this.sTATUSNAMEDataGridViewTextBoxColumn});
            this.gridcomp.DataSource = this.compviewBindingSource;
            this.gridcomp.Location = new System.Drawing.Point(248, 243);
            this.gridcomp.Name = "gridcomp";
            this.gridcomp.Size = new System.Drawing.Size(512, 240);
            this.gridcomp.TabIndex = 127;
            // 
            // cLUBIDDataGridViewTextBoxColumn1
            // 
            this.cLUBIDDataGridViewTextBoxColumn1.DataPropertyName = "CLUB_ID";
            this.cLUBIDDataGridViewTextBoxColumn1.HeaderText = "CLUB_ID";
            this.cLUBIDDataGridViewTextBoxColumn1.Name = "cLUBIDDataGridViewTextBoxColumn1";
            // 
            // cLUBNAMEDataGridViewTextBoxColumn2
            // 
            this.cLUBNAMEDataGridViewTextBoxColumn2.DataPropertyName = "CLUB_NAME";
            this.cLUBNAMEDataGridViewTextBoxColumn2.HeaderText = "CLUB_NAME";
            this.cLUBNAMEDataGridViewTextBoxColumn2.Name = "cLUBNAMEDataGridViewTextBoxColumn2";
            // 
            // cOMPNAMEDataGridViewTextBoxColumn
            // 
            this.cOMPNAMEDataGridViewTextBoxColumn.DataPropertyName = "COMP_NAME";
            this.cOMPNAMEDataGridViewTextBoxColumn.HeaderText = "COMP_NAME";
            this.cOMPNAMEDataGridViewTextBoxColumn.Name = "cOMPNAMEDataGridViewTextBoxColumn";
            // 
            // sTATUSNAMEDataGridViewTextBoxColumn
            // 
            this.sTATUSNAMEDataGridViewTextBoxColumn.DataPropertyName = "STATUS_NAME";
            this.sTATUSNAMEDataGridViewTextBoxColumn.HeaderText = "STATUS_NAME";
            this.sTATUSNAMEDataGridViewTextBoxColumn.Name = "sTATUSNAMEDataGridViewTextBoxColumn";
            // 
            // compviewBindingSource
            // 
            this.compviewBindingSource.DataMember = "comp_view";
            this.compviewBindingSource.DataSource = this.pldataDataSet3;
            // 
            // pldataDataSet3
            // 
            this.pldataDataSet3.DataSetName = "pldataDataSet3";
            this.pldataDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(605, 197);
            this.label32.MinimumSize = new System.Drawing.Size(5, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(125, 16);
            this.label32.TabIndex = 126;
            this.label32.Text = "FILTER BY STATUS:";
            // 
            // btncompdelete
            // 
            this.btncompdelete.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncompdelete.Location = new System.Drawing.Point(761, 144);
            this.btncompdelete.Name = "btncompdelete";
            this.btncompdelete.Size = new System.Drawing.Size(75, 23);
            this.btncompdelete.TabIndex = 125;
            this.btncompdelete.Text = "DELETE";
            this.btncompdelete.UseVisualStyleBackColor = true;
            this.btncompdelete.Click += new System.EventHandler(this.btncompdelete_Click);
            // 
            // btncompupdate
            // 
            this.btncompupdate.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncompupdate.Location = new System.Drawing.Point(761, 115);
            this.btncompupdate.Name = "btncompupdate";
            this.btncompupdate.Size = new System.Drawing.Size(75, 23);
            this.btncompupdate.TabIndex = 124;
            this.btncompupdate.Text = "UPDATE";
            this.btncompupdate.UseVisualStyleBackColor = true;
            this.btncompupdate.Click += new System.EventHandler(this.btncompupdate_Click);
            // 
            // btncompadd
            // 
            this.btncompadd.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncompadd.Location = new System.Drawing.Point(761, 85);
            this.btncompadd.Name = "btncompadd";
            this.btncompadd.Size = new System.Drawing.Size(75, 23);
            this.btncompadd.TabIndex = 123;
            this.btncompadd.Text = "ADD";
            this.btncompadd.UseVisualStyleBackColor = true;
            this.btncompadd.Click += new System.EventHandler(this.btncompadd_Click);
            // 
            // compfiltstat
            // 
            this.compfiltstat.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compfiltstat.FormattingEnabled = true;
            this.compfiltstat.Items.AddRange(new object[] {
            "Alphabetical: A-Z",
            "Alphabetical: Z-A"});
            this.compfiltstat.Location = new System.Drawing.Point(599, 213);
            this.compfiltstat.Name = "compfiltstat";
            this.compfiltstat.Size = new System.Drawing.Size(121, 24);
            this.compfiltstat.TabIndex = 122;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(435, 197);
            this.label33.MinimumSize = new System.Drawing.Size(5, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(154, 16);
            this.label33.TabIndex = 121;
            this.label33.Text = "FILTER BY COMP NAME:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(272, 197);
            this.label34.MinimumSize = new System.Drawing.Size(5, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(151, 16);
            this.label34.TabIndex = 120;
            this.label34.Text = "FILTER BY CLUB NAME:";
            // 
            // compfiltcomp
            // 
            this.compfiltcomp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compfiltcomp.FormattingEnabled = true;
            this.compfiltcomp.Items.AddRange(new object[] {
            "Alphabetical: A-Z",
            "Alphabetical: Z-A"});
            this.compfiltcomp.Location = new System.Drawing.Point(449, 213);
            this.compfiltcomp.Name = "compfiltcomp";
            this.compfiltcomp.Size = new System.Drawing.Size(121, 24);
            this.compfiltcomp.TabIndex = 119;
            // 
            // compfilterclub
            // 
            this.compfilterclub.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compfilterclub.FormattingEnabled = true;
            this.compfilterclub.Items.AddRange(new object[] {
            "Club Name: A-Z",
            "Club Name: Z-A"});
            this.compfilterclub.Location = new System.Drawing.Point(288, 213);
            this.compfilterclub.Name = "compfilterclub";
            this.compfilterclub.Size = new System.Drawing.Size(121, 24);
            this.compfilterclub.TabIndex = 118;
            // 
            // btncomp2nat
            // 
            this.btncomp2nat.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomp2nat.Location = new System.Drawing.Point(572, 98);
            this.btncomp2nat.Name = "btncomp2nat";
            this.btncomp2nat.Size = new System.Drawing.Size(125, 23);
            this.btncomp2nat.TabIndex = 117;
            this.btncomp2nat.Text = "NATIONAL TEAM";
            this.btncomp2nat.UseVisualStyleBackColor = true;
            this.btncomp2nat.Click += new System.EventHandler(this.btncomp2nat_Click);
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(572, 59);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(125, 23);
            this.button20.TabIndex = 116;
            this.button20.Text = "COMPETITION";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // btncomp2his
            // 
            this.btncomp2his.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomp2his.Location = new System.Drawing.Point(481, 97);
            this.btncomp2his.Name = "btncomp2his";
            this.btncomp2his.Size = new System.Drawing.Size(75, 23);
            this.btncomp2his.TabIndex = 115;
            this.btncomp2his.Text = "HISTORY";
            this.btncomp2his.UseVisualStyleBackColor = true;
            this.btncomp2his.Click += new System.EventHandler(this.btncomp2his_Click);
            // 
            // btncomp2man
            // 
            this.btncomp2man.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomp2man.Location = new System.Drawing.Point(380, 97);
            this.btncomp2man.Name = "btncomp2man";
            this.btncomp2man.Size = new System.Drawing.Size(86, 23);
            this.btncomp2man.TabIndex = 114;
            this.btncomp2man.Text = "MANAGER";
            this.btncomp2man.UseVisualStyleBackColor = true;
            this.btncomp2man.Click += new System.EventHandler(this.btncomp2man_Click);
            // 
            // btncomp2club
            // 
            this.btncomp2club.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomp2club.Location = new System.Drawing.Point(481, 58);
            this.btncomp2club.Name = "btncomp2club";
            this.btncomp2club.Size = new System.Drawing.Size(75, 23);
            this.btncomp2club.TabIndex = 113;
            this.btncomp2club.Text = "CLUB";
            this.btncomp2club.UseVisualStyleBackColor = true;
            this.btncomp2club.Click += new System.EventHandler(this.btncomp2club_Click);
            // 
            // txtsearchcomp
            // 
            this.txtsearchcomp.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchcomp.Location = new System.Drawing.Point(329, 163);
            this.txtsearchcomp.Name = "txtsearchcomp";
            this.txtsearchcomp.Size = new System.Drawing.Size(368, 23);
            this.txtsearchcomp.TabIndex = 112;
            // 
            // btncompfilter
            // 
            this.btncompfilter.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncompfilter.Location = new System.Drawing.Point(876, 134);
            this.btncompfilter.Name = "btncompfilter";
            this.btncompfilter.Size = new System.Drawing.Size(131, 76);
            this.btncompfilter.TabIndex = 111;
            this.btncompfilter.Text = "FILTER";
            this.btncompfilter.UseVisualStyleBackColor = true;
            this.btncompfilter.Click += new System.EventHandler(this.btncompfilter_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(285, 78);
            this.label35.MinimumSize = new System.Drawing.Size(5, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(92, 16);
            this.label35.TabIndex = 110;
            this.label35.Text = "SEARCH FOR:";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(57, 60);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(191, 107);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 109;
            this.pictureBox7.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(6, 18);
            this.label36.MinimumSize = new System.Drawing.Size(5, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(542, 25);
            this.label36.TabIndex = 108;
            this.label36.Text = "PREMIER LEAGUE PLAYER COMPETITION DATABASE";
            // 
            // playerrecordBindingSource1
            // 
            this.playerrecordBindingSource1.DataMember = "player_record";
            this.playerrecordBindingSource1.DataSource = this.pldataDataSetBindingSource;
            // 
            // pldataDataSetBindingSource
            // 
            this.pldataDataSetBindingSource.DataSource = this.pldataDataSet;
            this.pldataDataSetBindingSource.Position = 0;
            // 
            // playerrecordibfk1BindingSource
            // 
            this.playerrecordibfk1BindingSource.DataMember = "player_record_ibfk_1";
            this.playerrecordibfk1BindingSource.DataSource = this.playerBindingSource;
            // 
            // competitionstatushasclubibfk2BindingSource
            // 
            this.competitionstatushasclubibfk2BindingSource.DataMember = "competition_status_has_club_ibfk_2";
            this.competitionstatushasclubibfk2BindingSource.DataSource = this.clubBindingSource;
            // 
            // playerrecordibfk1BindingSource1
            // 
            this.playerrecordibfk1BindingSource1.DataMember = "player_record_ibfk_1";
            this.playerrecordibfk1BindingSource1.DataSource = this.playerBindingSource;
            // 
            // playerrecordBindingSource2
            // 
            this.playerrecordBindingSource2.DataMember = "player_record";
            this.playerrecordBindingSource2.DataSource = this.pldataDataSet;
            // 
            // playerrecordBindingSource
            // 
            this.playerrecordBindingSource.DataMember = "player_record";
            this.playerrecordBindingSource.DataSource = this.pldataDataSet;
            // 
            // playerTableAdapter
            // 
            this.playerTableAdapter.ClearBeforeFill = true;
            // 
            // clubTableAdapter
            // 
            this.clubTableAdapter.ClearBeforeFill = true;
            // 
            // managerTableAdapter
            // 
            this.managerTableAdapter.ClearBeforeFill = true;
            // 
            // national_teamTableAdapter
            // 
            this.national_teamTableAdapter.ClearBeforeFill = true;
            // 
            // player_recordTableAdapter
            // 
            this.player_recordTableAdapter.ClearBeforeFill = true;
            // 
            // competition_status_has_clubTableAdapter
            // 
            this.competition_status_has_clubTableAdapter.ClearBeforeFill = true;
            // 
            // pldataDataSet2
            // 
            this.pldataDataSet2.DataSetName = "pldataDataSet";
            this.pldataDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // playerBindingSource1
            // 
            this.playerBindingSource1.DataMember = "player";
            this.playerBindingSource1.DataSource = this.pldataDataSet2;
            // 
            // player_record_view1TableAdapter
            // 
            this.player_record_view1TableAdapter.ClearBeforeFill = true;
            // 
            // comp_viewTableAdapter
            // 
            this.comp_viewTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1042, 180);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 40;
            this.button1.Text = "RESTART";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1268, 589);
            this.Controls.Add(this.tabswitch);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabswitch.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridadminplayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridclub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clubBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.managerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridnat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nationalteamBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridhis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordview1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridcomp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.compviewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordibfk1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.competitionstatushasclubibfk2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordibfk1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerrecordBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pldataDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Button btnnormaluser;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.TabControl tabswitch;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lbladminpageswitch;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnadminfilter;
        private System.Windows.Forms.TextBox txtadminplayer;
        private System.Windows.Forms.Button btnadminnational;
        private System.Windows.Forms.Button btnadmincomp;
        private System.Windows.Forms.Button btnadminrecord;
        private System.Windows.Forms.Button btnadminmanager;
        private System.Windows.Forms.Button btnadminclub;
        private System.Windows.Forms.Button btnadminplayer;
        private System.Windows.Forms.ComboBox cbadmingoalfilter;
        private System.Windows.Forms.Label lbladminvaluefilter;
        private System.Windows.Forms.ComboBox cbadminvaluefilter;
        private System.Windows.Forms.Label lbladminnamefilter;
        private System.Windows.Forms.Label lbladmingoalfilter;
        private System.Windows.Forms.ComboBox cbadminnamefilter;
        private System.Windows.Forms.Label lbladmintext;
        private pldataDataSet pldataDataSet;
        private System.Windows.Forms.BindingSource playerBindingSource;
        private pldataDataSetTableAdapters.playerTableAdapter playerTableAdapter;
        private System.Windows.Forms.DataGridView gridadminplayer;
        private System.Windows.Forms.Button btnadminplayerdelete;
        private System.Windows.Forms.Button btnadminplayerupdate;
        private System.Windows.Forms.Button btnadminplayeradd;
        private System.Windows.Forms.TextBox txtat4;
        private System.Windows.Forms.TextBox txtat3;
        private System.Windows.Forms.TextBox txtat2;
        private System.Windows.Forms.TextBox txtat1;
        private System.Windows.Forms.TextBox txtat14;
        private System.Windows.Forms.TextBox txtat13;
        private System.Windows.Forms.TextBox txtat12;
        private System.Windows.Forms.TextBox txtat11;
        private System.Windows.Forms.TextBox txtat10;
        private System.Windows.Forms.TextBox txtat9;
        private System.Windows.Forms.TextBox txtat8;
        private System.Windows.Forms.TextBox txtat7;
        private System.Windows.Forms.TextBox txtat6;
        private System.Windows.Forms.TextBox txtat5;
        private System.Windows.Forms.Label lblat14;
        private System.Windows.Forms.Label lblat13;
        private System.Windows.Forms.Label lblat12;
        private System.Windows.Forms.Label lblat11;
        private System.Windows.Forms.Label lblat10;
        private System.Windows.Forms.Label lblat9;
        private System.Windows.Forms.Label lblat8;
        private System.Windows.Forms.Label lblat7;
        private System.Windows.Forms.Label lblat6;
        private System.Windows.Forms.Label lblat5;
        private System.Windows.Forms.Label lblat4;
        private System.Windows.Forms.Label lblat3;
        private System.Windows.Forms.Label lblat2;
        private System.Windows.Forms.Label lblat1;
        private System.Windows.Forms.Label lblplayeradd;
        private System.Windows.Forms.Label lbltitleadd;
        private System.Windows.Forms.Button btnaddplayer;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btndeleteplayer;
        private System.Windows.Forms.TextBox txtdelete;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbldelete;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox txtvalupdate;
        private System.Windows.Forms.Label lblvalnew;
        private System.Windows.Forms.TextBox txtupdateID;
        private System.Windows.Forms.Label lblupdateID;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.TextBox txtupdateatt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblupdateatt;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnclubdelete;
        private System.Windows.Forms.Button btnclubupdate;
        private System.Windows.Forms.Button btnclubadd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox clubfiltercap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox clubfiltername;
        private System.Windows.Forms.ComboBox clubfiltercity;
        private System.Windows.Forms.Button btnclub2nat;
        private System.Windows.Forms.Button btnclub2comp;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnclub2man;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox txtsearchclub;
        private System.Windows.Forms.Button btnfilterclub;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private pldataDataSet pldataDataSet1;
        private System.Windows.Forms.BindingSource clubBindingSource;
        private pldataDataSetTableAdapters.clubTableAdapter clubTableAdapter;
        private System.Windows.Forms.DataGridView gridclub;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubStadiumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubCapacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn managerManIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnclub2player;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button btnman2player;
        private System.Windows.Forms.DataGridView gridman;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnmandelete;
        private System.Windows.Forms.Button btnmanupdate;
        private System.Windows.Forms.Button btnmanadd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox ma;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button btnman2nat;
        private System.Windows.Forms.Button btnman2comp;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button btnman2club;
        private System.Windows.Forms.TextBox txtsearchman;
        private System.Windows.Forms.Button btnmanfilter;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridViewTextBoxColumn manIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manLnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manFnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manNatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manDOBDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource managerBindingSource;
        private pldataDataSetTableAdapters.managerTableAdapter managerTableAdapter;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button btnnat2player;
        private System.Windows.Forms.DataGridView gridnat;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnnatdelete;
        private System.Windows.Forms.Button btnnatupdate;
        private System.Windows.Forms.Button btnnatadd;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox natteamcap;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox natfiltername;
        private System.Windows.Forms.ComboBox natteamcity;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btnnat2comp;
        private System.Windows.Forms.Button btnnat2hist;
        private System.Windows.Forms.Button btnnat2man;
        private System.Windows.Forms.Button btnnat2club;
        private System.Windows.Forms.TextBox txtsearchnat;
        private System.Windows.Forms.Button btnnatfilter;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DataGridViewTextBoxColumn natTeamCountryDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn natTeamStadiumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn natTeamCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn natTeamCapacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource nationalteamBindingSource;
        private pldataDataSetTableAdapters.national_teamTableAdapter national_teamTableAdapter;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button btnhis2player;
        private System.Windows.Forms.DataGridView gridhis;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnhisdelete;
        private System.Windows.Forms.Button btnhisupdate;
        private System.Windows.Forms.Button btnhisadd;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox hisfilterdate;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox hisfiltername;
        private System.Windows.Forms.ComboBox hisfilterclub;
        private System.Windows.Forms.Button btnhisttonat;
        private System.Windows.Forms.Button btnhist2comp;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button btnhis2man;
        private System.Windows.Forms.Button btnhis2club;
        private System.Windows.Forms.TextBox txtsearchhis;
        private System.Windows.Forms.Button btnhisfilter;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.BindingSource playerrecordBindingSource;
        private pldataDataSetTableAdapters.player_recordTableAdapter player_recordTableAdapter;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Button btncomp2play;
        private System.Windows.Forms.DataGridView gridcomp;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button btncompdelete;
        private System.Windows.Forms.Button btncompupdate;
        private System.Windows.Forms.Button btncompadd;
        private System.Windows.Forms.ComboBox compfiltstat;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox compfiltcomp;
        private System.Windows.Forms.ComboBox compfilterclub;
        private System.Windows.Forms.Button btncomp2nat;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button btncomp2his;
        private System.Windows.Forms.Button btncomp2man;
        private System.Windows.Forms.Button btncomp2club;
        private System.Windows.Forms.TextBox txtsearchcomp;
        private System.Windows.Forms.Button btncompfilter;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtdelete1;
        private System.Windows.Forms.Label lbldelete1;
        private System.Windows.Forms.TextBox txtupdatestart;
        private System.Windows.Forms.Label lblupdatestart;
        private System.Windows.Forms.BindingSource pldataDataSetBindingSource;
        private System.Windows.Forms.BindingSource playerrecordBindingSource1;
        private System.Windows.Forms.BindingSource playerrecordibfk1BindingSource;
        private System.Windows.Forms.BindingSource competitionstatushasclubibfk2BindingSource;
        private pldataDataSetTableAdapters.competition_status_has_clubTableAdapter competition_status_has_clubTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubClubIDDataGridViewTextBoxColumn2;
        private pldataDataSet pldataDataSet2;
        private System.Windows.Forms.BindingSource playerBindingSource1;
        private System.Windows.Forms.BindingSource playerrecordBindingSource2;
        private System.Windows.Forms.BindingSource playerrecordibfk1BindingSource1;
        private pldataDataSet2 pldataDataSet21;
        private System.Windows.Forms.BindingSource playerrecordview1BindingSource;
        private pldataDataSet2TableAdapters.player_record_view1TableAdapter player_record_view1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn pLAYERLNAMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pLAYERFNAMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLUBNAMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tEAMSTARTDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLUBIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLUBNAMEDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMPNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTATUSNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource compviewBindingSource;
        private pldataDataSet3 pldataDataSet3;
        private pldataDataSet3TableAdapters.comp_viewTableAdapter comp_viewTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerJerseyNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerLnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerFnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerNatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerDOBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerHeightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerWeightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerGoalsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerAssistsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerPosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerValUSDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn natTeamCountryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubClubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblplayermode;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label lblclubmode;
        private System.Windows.Forms.Label lblmanmode;
        private System.Windows.Forms.Label lblnatmode;
        private System.Windows.Forms.Label lblhismode;
        private System.Windows.Forms.Label lblcompmode;
        private System.Windows.Forms.Button button1;
    }
}

